extends Node3D

const FighterScript = preload("res://fighter.gd")
const HudScript = preload("res://hud.gd")
const SfxScript = preload("res://sfx.gd")
const GROUND = preload("res://shaders/ground.gdshader")
const ROCK = preload("res://shaders/rock.gdshader")
const BURST = preload("res://shaders/burst.gdshader")
const DECAL = preload("res://shaders/decal.gdshader")

var player
var enemy
var hud
var cam
var sfx
var state = "title"
var shake = 0.0
var speed_fx = 0.0
var hitstop = 0.0
var flash = 0.0
var banner = ""
var banner_t = 0.0
var over_t = 0.0
var result = ""
var look_pt = Vector3(0, 3, 0)
var cam_flat = Vector3(0, 0, -1)
var roll_t = 0.0
var rng = RandomNumberGenerator.new()


func _ready():
    process_priority = 100
    rng.seed = 7
    sfx = SfxScript.new()
    add_child(sfx)
    _build_world()
    cam = Camera3D.new()
    cam.fov = 70.0
    cam.far = 1200.0
    add_child(cam)
    cam.current = true
    player = FighterScript.new()
    add_child(player)
    player.setup(self, true, "KAIRO", Color(0.95, 0.76, 0.62), Color(0.06, 0.06, 0.1), Color(0.1, 0.14, 0.34), Color(0.15, 0.85, 0.95), Color(0.3, 0.75, 1.0), Color(0.95, 0.95, 1.0))
    enemy = FighterScript.new()
    add_child(enemy)
    enemy.setup(self, false, "VORTH", Color(0.8, 0.7, 0.92), Color(0.92, 0.92, 1.0), Color(0.22, 0.08, 0.3), Color(0.95, 0.15, 0.3), Color(1.0, 0.2, 0.3), Color(0.12, 0.05, 0.18))
    enemy.speed_mul = 0.85
    enemy.dmg_mul = 0.8
    player.opp = enemy
    enemy.opp = player
    var layer = CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    hud.main = self
    layer.add_child(hud)
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    reset_fight()
    player.position = Vector3(0, 3, 3.5)
    enemy.position = Vector3(0, 3, -3.5)
    player.snap_face()
    enemy.snap_face()


func _rock_mat(a, b, t):
    var m = ShaderMaterial.new()
    m.shader = ROCK
    m.set_shader_parameter("col_a", a)
    m.set_shader_parameter("col_b", b)
    m.set_shader_parameter("col_top", t)
    return m


func _build_world():
    var env = Environment.new()
    var sky = Sky.new()
    var sm = ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.1, 0.24, 0.58)
    sm.sky_horizon_color = Color(0.72, 0.62, 0.52)
    sm.sky_curve = 0.2
    sm.ground_horizon_color = Color(0.6, 0.5, 0.42)
    sm.ground_bottom_color = Color(0.25, 0.2, 0.17)
    sm.sky_energy_multiplier = 0.9
    sky.sky_material = sm
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.55
    env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
    env.tonemap_mode = Environment.TONE_MAPPER_ACES
    env.tonemap_exposure = 0.9
    env.tonemap_white = 6.0
    env.glow_enabled = true
    env.glow_intensity = 0.5
    env.glow_bloom = 0.05
    env.glow_hdr_threshold = 1.3
    env.glow_blend_mode = Environment.GLOW_BLEND_MODE_SCREEN
    env.adjustment_enabled = true
    env.adjustment_saturation = 1.0
    env.adjustment_contrast = 1.08
    env.fog_enabled = true
    env.fog_light_color = Color(0.62, 0.55, 0.5)
    env.fog_density = 0.003
    env.fog_sky_affect = 0.1
    var we = WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-36, -50, 0)
    sun.light_color = Color(1.0, 0.93, 0.82)
    sun.light_energy = 1.0
    sun.sky_mode = DirectionalLight3D.SKY_MODE_LIGHT_ONLY
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 45.0
    add_child(sun)

    var ground = MeshInstance3D.new()
    var pm = PlaneMesh.new()
    pm.size = Vector2(1600, 1600)
    ground.mesh = pm
    var gm = ShaderMaterial.new()
    gm.shader = GROUND
    ground.material_override = gm
    add_child(ground)

    for i in 26:
        var a = rng.randf() * TAU
        var r = rng.randf_range(45.0, 130.0)
        var h = rng.randf_range(10.0, 55.0)
        var rock = MeshInstance3D.new()
        var cm = CylinderMesh.new()
        cm.top_radius = rng.randf_range(1.5, 4.0)
        cm.bottom_radius = cm.top_radius + rng.randf_range(2.5, 6.0)
        cm.height = h
        cm.radial_segments = 9
        cm.rings = 1
        rock.mesh = cm
        rock.position = Vector3(cos(a) * r, h * 0.5, sin(a) * r)
        rock.rotation.y = rng.randf() * TAU
        rock.material_override = _rock_mat(Color(0.62, 0.4, 0.26), Color(0.46, 0.29, 0.2), Color(0.72, 0.56, 0.36))
        rock.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(rock)

    for i in 8:
        var a = float(i) / 8.0 * TAU + 0.3
        var r = rng.randf_range(170.0, 230.0)
        var mesa = MeshInstance3D.new()
        var mc = CylinderMesh.new()
        mc.top_radius = rng.randf_range(10.0, 16.0)
        mc.bottom_radius = mc.top_radius + rng.randf_range(4.0, 9.0)
        mc.height = rng.randf_range(35.0, 70.0)
        mc.radial_segments = 10
        mc.rings = 1
        mesa.mesh = mc
        mesa.position = Vector3(cos(a) * r, mc.height * 0.5, sin(a) * r)
        mesa.material_override = _rock_mat(Color(0.58, 0.4, 0.3), Color(0.42, 0.29, 0.24), Color(0.7, 0.55, 0.4))
        mesa.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mesa)

    for i in 9:
        var a = float(i) / 9.0 * TAU
        var mt = MeshInstance3D.new()
        var mcn = CylinderMesh.new()
        mcn.top_radius = 0.0
        mcn.bottom_radius = rng.randf_range(80.0, 140.0)
        mcn.height = rng.randf_range(110.0, 200.0)
        mcn.radial_segments = 6
        mt.mesh = mcn
        mt.position = Vector3(cos(a) * 420.0, mcn.height * 0.5, sin(a) * 420.0)
        mt.material_override = _rock_mat(Color(0.5, 0.52, 0.68), Color(0.44, 0.46, 0.64), Color(0.62, 0.64, 0.78))
        mt.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
        add_child(mt)

    var motes = CPUParticles3D.new()
    motes.amount = 70
    motes.lifetime = 9.0
    motes.preprocess = 9.0
    motes.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    motes.emission_box_extents = Vector3(45, 14, 45)
    motes.direction = Vector3(1, 0.2, 0.3)
    motes.spread = 180.0
    motes.initial_velocity_min = 0.3
    motes.initial_velocity_max = 1.0
    motes.gravity = Vector3.ZERO
    motes.mesh = make_dot_mesh(Color(1.0, 0.95, 0.8), 0.05)
    add_child(motes)
    motes.position = Vector3(0, 12, 0)


func reset_fight():
    Engine.time_scale = 1.0
    hitstop = 0.0
    flash = 0.0
    for b in get_tree().get_nodes_in_group("blasts"):
        b.queue_free()
    player.reset(Vector3(0, 4, 14))
    enemy.reset(Vector3(0, 4, -14))
    player.snap_face()
    enemy.snap_face()
    look_pt = Vector3(0, 3, 0)
    cam_flat = Vector3(0, 0, -1)
    result = ""
    over_t = 0.0


func start_match():
    reset_fight()
    state = "fight"
    sfx.play("fight", -4.0)
    banner = "BATTLE START"
    banner_t = 1.4


func try_restart():
    if over_t > 1.5:
        start_match()


func on_ko(loser):
    state = "over"
    over_t = 0.0
    if loser == enemy:
        result = "VICTORY"
    else:
        result = "DEFEAT"
    hitstop = 0.8
    shake = 0.7
    flash = 0.5
    sfx.play("ko")
    sfx.set_loop("charge", false)


func make_dot_mesh(col, size):
    var m = SphereMesh.new()
    m.radius = size
    m.height = size * 2.0
    m.radial_segments = 6
    m.rings = 3
    var mat = StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = col
    m.material = mat
    return m


func spawn_burst(pos, col, size, dur = 0.35, ring_amt = 1.0, flare_amt = 1.0, flat = false):
    var mi = MeshInstance3D.new()
    if flat:
        var pm = PlaneMesh.new()
        pm.size = Vector2(1, 1)
        mi.mesh = pm
    else:
        var qm = QuadMesh.new()
        qm.size = Vector2(1, 1)
        mi.mesh = qm
    var mat = ShaderMaterial.new()
    mat.shader = BURST
    mat.set_shader_parameter("col", col)
    mat.set_shader_parameter("size", size * 0.3)
    mat.set_shader_parameter("fade", 1.0)
    mat.set_shader_parameter("ring_amt", ring_amt)
    mat.set_shader_parameter("flare_amt", flare_amt)
    mat.set_shader_parameter("billboard", not flat)
    mi.material_override = mat
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    mi.global_position = pos
    var tw = create_tween()
    tw.set_parallel(true)
    tw.tween_property(mat, "shader_parameter/size", size, dur)
    tw.tween_property(mat, "shader_parameter/fade", 0.0, dur)
    tw.chain().tween_callback(mi.queue_free)


func spawn_explosion(pos, col, size):
    var m = MeshInstance3D.new()
    var s = SphereMesh.new()
    s.radius = 1.0
    s.height = 2.0
    s.radial_segments = 16
    s.rings = 8
    m.mesh = s
    var mat = StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    mat.albedo_color = Color(col.r * 1.4, col.g * 1.4, col.b * 1.4, 0.4)
    m.material_override = mat
    m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(m)
    m.global_position = pos
    m.scale = Vector3.ONE * size * 0.2
    if size >= 2.0:
        spawn_burst(pos, col, size * 1.3, 0.35, 0.8, 0.6, false)
        if size >= 4.0:
            sfx.play("boom", -2.0)
        else:
            sfx.play("boom", -9.0)
    var tw = create_tween()
    tw.set_parallel(true)
    tw.tween_property(m, "scale", Vector3.ONE * size * 0.5, 0.3)
    tw.tween_property(mat, "albedo_color:a", 0.0, 0.3)
    tw.chain().tween_callback(m.queue_free)


func spawn_hit_fx(pos, heavy):
    var sz = 1.3
    var cnt = 12
    if heavy:
        sz = 2.6
        cnt = 26
    spawn_burst(pos, Color(1.0, 0.95, 0.8), sz * 1.6, 0.22, 0.7, 0.8, false)
    spawn_explosion(pos, Color(1.0, 0.95, 0.8), sz)
    var p = CPUParticles3D.new()
    p.one_shot = true
    p.explosiveness = 1.0
    p.amount = cnt
    p.lifetime = 0.45
    p.direction = Vector3.UP
    p.spread = 180.0
    p.initial_velocity_min = 5.0
    p.initial_velocity_max = 14.0
    p.gravity = Vector3.ZERO
    p.local_coords = false
    p.mesh = make_dot_mesh(Color(2.2, 1.9, 0.9), 0.07)
    add_child(p)
    p.global_position = pos
    p.emitting = true
    get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func dust_puff(pos, s):
    var p = CPUParticles3D.new()
    p.one_shot = true
    p.explosiveness = 0.9
    p.amount = 6
    p.lifetime = 0.9
    p.direction = Vector3.UP
    p.spread = 60.0
    p.initial_velocity_min = 1.0
    p.initial_velocity_max = 3.0 * s
    p.gravity = Vector3(0, 0.5, 0)
    p.local_coords = false
    p.mesh = _dust_mesh(0.35 * s)
    p.color_ramp = _fade_ramp(Color(0.8, 0.68, 0.55, 0.6))
    add_child(p)
    p.global_position = pos
    p.emitting = true
    get_tree().create_timer(1.5).timeout.connect(p.queue_free)


func _fade_ramp(c):
    var g = Gradient.new()
    g.set_color(0, c)
    g.set_color(1, Color(c.r, c.g, c.b, 0.0))
    return g


func _dust_mesh(r):
    var m = SphereMesh.new()
    m.radius = r
    m.height = r * 2.0
    m.radial_segments = 8
    m.rings = 4
    var mat = StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.vertex_color_use_as_albedo = true
    mat.albedo_color = Color(1, 1, 1, 1)
    m.material = mat
    return m


func ground_impact(pos, size):
    var gp = Vector3(pos.x, 0.06, pos.z)
    spawn_burst(gp, Color(1.0, 0.8, 0.5), size * 4.0, 0.5, 1.0, 0.0, true)
    var d = CPUParticles3D.new()
    d.one_shot = true
    d.explosiveness = 0.95
    d.amount = 22
    d.lifetime = 1.4
    d.direction = Vector3.UP
    d.spread = 75.0
    d.initial_velocity_min = 3.0
    d.initial_velocity_max = 8.0 * max(size * 0.5, 1.0)
    d.gravity = Vector3(0, 0.8, 0)
    d.local_coords = false
    d.mesh = _dust_mesh(0.5)
    d.scale_amount_min = 1.0
    d.scale_amount_max = 2.6
    d.color_ramp = _fade_ramp(Color(0.8, 0.68, 0.55, 0.75))
    add_child(d)
    d.global_position = gp
    d.emitting = true
    get_tree().create_timer(2.0).timeout.connect(d.queue_free)
    var rk = CPUParticles3D.new()
    rk.one_shot = true
    rk.explosiveness = 1.0
    rk.amount = 14
    rk.lifetime = 1.6
    rk.direction = Vector3.UP
    rk.spread = 55.0
    rk.initial_velocity_min = 8.0
    rk.initial_velocity_max = 18.0
    rk.gravity = Vector3(0, -22.0, 0)
    rk.local_coords = false
    var bm = BoxMesh.new()
    bm.size = Vector3(0.28, 0.28, 0.28)
    bm.material = _rock_mat(Color(0.62, 0.4, 0.26), Color(0.46, 0.29, 0.2), Color(0.72, 0.56, 0.36))
    rk.mesh = bm
    add_child(rk)
    rk.global_position = gp
    rk.emitting = true
    get_tree().create_timer(2.2).timeout.connect(rk.queue_free)
    var dec = MeshInstance3D.new()
    var dp = PlaneMesh.new()
    dp.size = Vector2(size * 5.0, size * 5.0)
    dec.mesh = dp
    var dm = ShaderMaterial.new()
    dm.shader = DECAL
    dec.material_override = dm
    dec.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(dec)
    dec.global_position = Vector3(pos.x, 0.04, pos.z)
    dec.rotation.y = rng.randf() * TAU
    var tw = create_tween()
    tw.tween_interval(6.0)
    tw.tween_property(dm, "shader_parameter/alpha", 0.0, 3.0)
    tw.tween_callback(dec.queue_free)
    shake = max(shake, 0.1 * size)


func _process(delta):
    if hitstop > 0.0:
        Engine.time_scale = 0.12
        hitstop -= delta / 0.12
        if hitstop <= 0.0:
            Engine.time_scale = 1.0
    var real = delta / max(Engine.time_scale, 0.05)
    if state == "over":
        over_t += real
    if banner_t > 0.0:
        banner_t -= real
    flash = max(0.0, flash - real * 2.2)
    speed_fx = max(0.0, speed_fx - delta * 2.5)
    _update_camera(delta)


func _update_camera(delta):
    var pp = player.position
    var ep = enemy.position
    if state == "title":
        var t = Time.get_ticks_msec() / 1000.0
        cam.position = Vector3(sin(t * 0.25) * 9.0, 3.4, cos(t * 0.25) * 9.0)
        cam.look_at(Vector3(0, 3.6, 0), Vector3.UP)
        return
    var to = ep - pp
    var flat = Vector3(to.x, 0.0, to.z)
    if flat.length() > 0.5:
        cam_flat = cam_flat.lerp(flat.normalized(), 1.0 - exp(-8.0 * delta)).normalized()
    var right = cam_flat.cross(Vector3.UP)
    var back = 6.8 + clamp(to.length() * 0.07, 0.0, 4.5)
    if player.dash_t > 0.0:
        back += 2.0
    var up = 2.0 + clamp(to.y * 0.12, -1.0, 2.0)
    var target_pos = pp - cam_flat * back + Vector3.UP * up + right * 1.7
    target_pos.y = max(target_pos.y, 1.0)
    cam.position = cam.position.lerp(target_pos, 1.0 - exp(-5.5 * delta))
    var want_look = pp + to * 0.45 + Vector3.UP * 0.8
    look_pt = look_pt.lerp(want_look, 1.0 - exp(-9.0 * delta))
    if (look_pt - cam.position).length() > 0.5:
        cam.look_at(look_pt, Vector3.UP)
    roll_t = lerp(roll_t, -clamp(player.vel.dot(right) / 20.0, -1.0, 1.0) * 0.07, 1.0 - exp(-6.0 * delta))
    cam.rotate_object_local(Vector3(0, 0, 1), roll_t)
    shake = max(0.0, shake - delta * 1.6)
    cam.h_offset = rng.randf_range(-1.0, 1.0) * shake * 0.5
    cam.v_offset = rng.randf_range(-1.0, 1.0) * shake * 0.5
    cam.fov = lerp(cam.fov, 70.0 + speed_fx * 22.0, 1.0 - exp(-12.0 * delta))
