extends Node3D

const FighterScript = preload("res://fighter.gd")
const HudScript = preload("res://hud.gd")

var player
var enemy
var hud
var cam
var state = "title"
var shake = 0.0
var speed_fx = 0.0
var hitstop = 0.0
var banner = ""
var banner_t = 0.0
var over_t = 0.0
var result = ""
var look_pt = Vector3(0, 3, 0)
var cam_flat = Vector3(0, 0, -1)
var rng = RandomNumberGenerator.new()


func _ready():
    process_priority = 100
    rng.seed = 7
    _build_world()
    cam = Camera3D.new()
    cam.fov = 68.0
    cam.far = 900.0
    add_child(cam)
    cam.current = true
    player = FighterScript.new()
    add_child(player)
    player.setup(self, true, "KAIRO", Color(0.97, 0.78, 0.62), Color(0.05, 0.05, 0.09), Color(0.96, 0.46, 0.1), Color(0.1, 0.25, 0.8), Color(0.35, 0.7, 1.0))
    enemy = FighterScript.new()
    add_child(enemy)
    enemy.setup(self, false, "VORTH", Color(0.82, 0.72, 0.95), Color(0.93, 0.93, 1.0), Color(0.32, 0.12, 0.5), Color(0.9, 0.15, 0.3), Color(1.0, 0.2, 0.3))
    enemy.speed_mul = 0.85
    enemy.dmg_mul = 0.8
    player.opp = enemy
    enemy.opp = player
    var layer = CanvasLayer.new()
    add_child(layer)
    hud = HudScript.new()
    hud.main = self
    layer.add_child(hud)
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    reset_fight()
    player.position = Vector3(0, 3, 3.5)
    enemy.position = Vector3(0, 3, -3.5)
    player.snap_face()
    enemy.snap_face()


func _build_world():
    var env = Environment.new()
    var sky = Sky.new()
    var sm = ProceduralSkyMaterial.new()
    sm.sky_top_color = Color(0.10, 0.28, 0.65)
    sm.sky_horizon_color = Color(0.75, 0.85, 0.95)
    sm.ground_horizon_color = Color(0.75, 0.85, 0.95)
    sm.ground_bottom_color = Color(0.45, 0.55, 0.65)
    sky.sky_material = sm
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.55, 0.6, 0.8)
    env.ambient_light_energy = 0.8
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.glow_enabled = true
    env.glow_intensity = 0.9
    env.glow_bloom = 0.15
    env.glow_hdr_threshold = 1.0
    env.fog_enabled = true
    env.fog_light_color = Color(0.75, 0.85, 0.95)
    env.fog_density = 0.005
    env.fog_sky_affect = 0.2
    var we = WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-50, -35, 0)
    sun.light_energy = 1.2
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 55.0
    add_child(sun)

    var ground = MeshInstance3D.new()
    var pm = PlaneMesh.new()
    pm.size = Vector2(900, 900)
    ground.mesh = pm
    var gm = ShaderMaterial.new()
    gm.shader = preload("res://shaders/ground.gdshader")
    ground.material_override = gm
    add_child(ground)

    for i in 24:
        var a = rng.randf() * TAU
        var r = rng.randf_range(42.0, 120.0)
        var h = rng.randf_range(8.0, 45.0)
        var rock = MeshInstance3D.new()
        var cm = CylinderMesh.new()
        cm.top_radius = rng.randf_range(1.0, 3.0)
        cm.bottom_radius = cm.top_radius + rng.randf_range(2.0, 5.0)
        cm.height = h
        cm.radial_segments = 8
        rock.mesh = cm
        rock.position = Vector3(cos(a) * r, h * 0.5, sin(a) * r)
        rock.material_override = FighterScript.make_toon(Color(0.5, 0.42, 0.36), 0.12)
        add_child(rock)

    for i in 9:
        var a = float(i) / 9.0 * TAU
        var mt = MeshInstance3D.new()
        var mc = CylinderMesh.new()
        mc.top_radius = 0.0
        mc.bottom_radius = rng.randf_range(60.0, 110.0)
        mc.height = rng.randf_range(90.0, 170.0)
        mc.radial_segments = 6
        mt.mesh = mc
        mt.position = Vector3(cos(a) * 300.0, mc.height * 0.5, sin(a) * 300.0)
        mt.material_override = FighterScript.make_toon(Color(0.4, 0.5, 0.65), 0.0)
        add_child(mt)


func reset_fight():
    Engine.time_scale = 1.0
    hitstop = 0.0
    for b in get_tree().get_nodes_in_group("blasts"):
        b.queue_free()
    player.reset(Vector3(0, 4, 14))
    enemy.reset(Vector3(0, 4, -14))
    player.snap_face()
    enemy.snap_face()
    look_pt = Vector3(0, 3, 0)
    cam_flat = Vector3(0, 0, -1)
    result = ""
    over_t = 0.0


func start_match():
    reset_fight()
    state = "fight"
    banner = "FIGHT!"
    banner_t = 1.3


func try_restart():
    if over_t > 1.5:
        start_match()


func on_ko(loser):
    state = "over"
    over_t = 0.0
    if loser == enemy:
        result = "VICTORY"
    else:
        result = "DEFEAT"
    hitstop = 0.8
    shake = 0.7


func make_dot_mesh(col, size):
    var m = SphereMesh.new()
    m.radius = size
    m.height = size * 2.0
    m.radial_segments = 6
    m.rings = 3
    var mat = StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = col
    m.material = mat
    return m


func spawn_explosion(pos, col, size):
    var m = MeshInstance3D.new()
    var s = SphereMesh.new()
    s.radius = 1.0
    s.height = 2.0
    s.radial_segments = 16
    s.rings = 8
    m.mesh = s
    var mat = StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    mat.albedo_color = Color(col.r * 2.0, col.g * 2.0, col.b * 2.0, 0.8)
    m.material_override = mat
    add_child(m)
    m.global_position = pos
    m.scale = Vector3.ONE * size * 0.3
    var tw = create_tween()
    tw.set_parallel(true)
    tw.tween_property(m, "scale", Vector3.ONE * size, 0.3)
    tw.tween_property(mat, "albedo_color:a", 0.0, 0.3)
    tw.chain().tween_callback(m.queue_free)


func spawn_hit_fx(pos, heavy):
    var sz = 1.3
    var cnt = 12
    if heavy:
        sz = 2.6
        cnt = 26
    spawn_explosion(pos, Color(1.0, 0.95, 0.8), sz)
    var p = CPUParticles3D.new()
    p.one_shot = true
    p.explosiveness = 1.0
    p.amount = cnt
    p.lifetime = 0.45
    p.direction = Vector3.UP
    p.spread = 180.0
    p.initial_velocity_min = 5.0
    p.initial_velocity_max = 14.0
    p.gravity = Vector3.ZERO
    p.local_coords = false
    p.mesh = make_dot_mesh(Color(3.0, 2.6, 1.2), 0.07)
    add_child(p)
    p.global_position = pos
    p.emitting = true
    get_tree().create_timer(1.0).timeout.connect(p.queue_free)


func _process(delta):
    if hitstop > 0.0:
        Engine.time_scale = 0.12
        hitstop -= delta / 0.12
        if hitstop <= 0.0:
            Engine.time_scale = 1.0
    var real = delta / max(Engine.time_scale, 0.05)
    if state == "over":
        over_t += real
    if banner_t > 0.0:
        banner_t -= real
    speed_fx = max(0.0, speed_fx - delta * 2.5)
    _update_camera(delta)


func _update_camera(delta):
    var pp = player.position
    var ep = enemy.position
    if state == "title":
        var t = Time.get_ticks_msec() / 1000.0
        cam.position = Vector3(sin(t * 0.25) * 9.0, 3.4, cos(t * 0.25) * 9.0)
        cam.look_at(Vector3(0, 3.6, 0), Vector3.UP)
        return
    var to = ep - pp
    var flat = Vector3(to.x, 0.0, to.z)
    if flat.length() > 0.5:
        cam_flat = cam_flat.lerp(flat.normalized(), 1.0 - exp(-8.0 * delta)).normalized()
    var right = cam_flat.cross(Vector3.UP)
    var back = 7.0 + clamp(to.length() * 0.08, 0.0, 4.0)
    var up = 2.2 + clamp(to.y * 0.15, -1.0, 2.0)
    var target_pos = pp - cam_flat * back + Vector3.UP * up + right * 1.5
    target_pos.y = max(target_pos.y, 1.0)
    cam.position = cam.position.lerp(target_pos, 1.0 - exp(-6.0 * delta))
    var want_look = pp + to * 0.45 + Vector3.UP * 0.8
    look_pt = look_pt.lerp(want_look, 1.0 - exp(-10.0 * delta))
    if (look_pt - cam.position).length() > 0.5:
        cam.look_at(look_pt, Vector3.UP)
    shake = max(0.0, shake - delta * 1.6)
    cam.h_offset = rng.randf_range(-1.0, 1.0) * shake * 0.5
    cam.v_offset = rng.randf_range(-1.0, 1.0) * shake * 0.5
    cam.fov = lerp(cam.fov, 68.0 + speed_fx * 22.0, 1.0 - exp(-12.0 * delta))
