extends Node

const RATE = 22050

var streams = {}
var pool = []
var pool_i = 0
var loops = {}


func _ready():
    for i in 12:
        var p = AudioStreamPlayer.new()
        add_child(p)
        pool.append(p)
    _build()
    for n in streams.keys():
        for ext in ["wav", "ogg", "mp3"]:
            var path = "res://sfx/sfx_%s.%s" % [n, ext]
            if ResourceLoader.exists(path):
                var s = load(path)
                if s != null:
                    streams[n] = s
                    break


func _n():
    return randf() * 2.0 - 1.0


func _tone(f, start, t):
    if t < start:
        return 0.0
    var u = t - start
    return sin(TAU * f * u) * exp(-u * 3.0) * 0.25


func _make(dur, fn, loop = false):
    var n = int(RATE * dur)
    var data = PackedByteArray()
    data.resize(n * 2)
    for i in n:
        var t = float(i) / RATE
        var v = clamp(fn.call(t, float(i) / n), -1.0, 1.0)
        data.encode_s16(i * 2, int(v * 30000.0))
    var s = AudioStreamWAV.new()
    s.format = AudioStreamWAV.FORMAT_16_BITS
    s.mix_rate = RATE
    s.stereo = false
    s.data = data
    if loop:
        s.loop_mode = AudioStreamWAV.LOOP_FORWARD
        s.loop_begin = 0
        s.loop_end = n
    return s


func _build():
    var st = [0.0]
    var st2 = [0.0]
    streams["punch"] = _make(0.2, func(t, p): return _n() * exp(-t * 35.0) * 0.7 + sin(TAU * (140.0 - 90.0 * p) * t) * exp(-t * 16.0) * 0.9)
    streams["heavy"] = _make(0.5, func(t, p): return _n() * exp(-t * 9.0) * 0.6 + sin(TAU * 60.0 * t) * exp(-t * 5.0))
    streams["swing"] = _make(0.22, func(t, p): return _n() * sin(PI * p) * 0.3)
    streams["blast"] = _make(0.3, func(t, p): return sin(TAU * (1100.0 * t - 750.0 * t * t / 0.6)) * exp(-t * 7.0) * 0.8 + _n() * exp(-t * 25.0) * 0.2)
    streams["boom"] = _make(0.8, func(t, p): return _boom(st, t))
    streams["dash"] = _make(0.32, func(t, p): return _whoosh(st2, p))
    streams["charge"] = _make(1.0, func(t, p): return (sin(TAU * 110.0 * t) * 0.4 + sin(TAU * 165.0 * t) * 0.25 + sin(TAU * 330.0 * t) * 0.12) * (0.7 + 0.3 * sin(TAU * 4.0 * t)), true)
    streams["ult_charge"] = _make(0.75, func(t, p): return sin(TAU * (200.0 * t + 1000.0 * t * t / 1.5)) * (0.2 + 0.8 * p) * 0.7 + _n() * 0.05 * p)
    streams["ult_fire"] = _make(0.9, func(t, p): return sin(TAU * (260.0 * t - 200.0 * t * t / 1.8)) * exp(-t * 3.0) * 0.8 + _n() * exp(-t * 8.0) * 0.4)
    streams["spark"] = _make(1.0, func(t, p): return _tone(440.0, 0.0, t) + _tone(554.0, 0.08, t) + _tone(659.0, 0.16, t) + _tone(880.0, 0.24, t) + _n() * exp(-t * 12.0) * 0.3)
    streams["ko"] = _make(1.2, func(t, p): return sin(TAU * (220.0 * t - 160.0 * t * t / 2.4)) * exp(-t * 2.5) * 0.9 + _n() * exp(-t * 10.0) * 0.4)
    streams["fight"] = _make(0.5, func(t, p): return (_tone(330.0, 0.0, t) + _tone(495.0, 0.0, t) + _tone(660.0, 0.12, t)) * 1.2)


func _boom(st, t):
    st[0] += (_n() - st[0]) * 0.12
    return st[0] * exp(-t * 4.0) * 3.0 + sin(TAU * 50.0 * t) * exp(-t * 6.0) * 0.6


func _whoosh(st, p):
    st[0] += (_n() - st[0]) * (0.05 + 0.5 * sin(PI * p))
    return st[0] * sin(PI * p) * 2.5


func play(n, vol = 0.0, pitch = 1.0):
    if not streams.has(n):
        return
    var p = pool[pool_i]
    pool_i = (pool_i + 1) % pool.size()
    p.stream = streams[n]
    p.volume_db = vol
    p.pitch_scale = pitch * randf_range(0.95, 1.05)
    p.play()


func set_loop(n, on, vol = -8.0):
    if not streams.has(n):
        return
    var p = loops.get(n, null)
    if p == null:
        p = AudioStreamPlayer.new()
        add_child(p)
        var s = streams[n]
        if s is AudioStreamOggVorbis or s is AudioStreamMP3:
            s.loop = true
        p.stream = s
        loops[n] = p
    p.volume_db = vol
    if on and not p.playing:
        p.play()
    elif not on and p.playing:
        p.stop()
