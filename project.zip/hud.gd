extends Control

var main
var stick = Vector2.ZERO
var held = {}
var taps = {}
var touches = {}
var layout = {}
var stick_c = Vector2(330, 640)
var stick_r = 170.0
var keymap = {KEY_J: "atk", KEY_K: "blast", KEY_L: "ult", KEY_SPACE: "dash", KEY_C: "charge", KEY_V: "spark", KEY_E: "up", KEY_Q: "down"}


func _ready():
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func held_btn(n):
    return held.get(n, false)


func tapped(n):
    if taps.get(n, false):
        taps[n] = false
        return true
    return false


func _layout():
    var S = get_viewport_rect().size
    stick_c = Vector2(330.0, S.y - 250.0)
    layout = {
        "atk": [Vector2(S.x - 260.0, S.y - 250.0), 120.0, "ATK", Color(1.0, 0.45, 0.2)],
        "blast": [Vector2(S.x - 520.0, S.y - 170.0), 95.0, "KI", Color(0.4, 0.8, 1.0)],
        "dash": [Vector2(S.x - 470.0, S.y - 390.0), 85.0, "DASH", Color(0.9, 0.9, 1.0)],
        "ult": [Vector2(S.x - 230.0, S.y - 500.0), 80.0, "ULT", Color(1.0, 0.3, 0.6)],
        "spark": [Vector2(S.x - 690.0, S.y - 330.0), 80.0, "SPARK", Color(1.0, 0.85, 0.2)],
        "charge": [Vector2(S.x - 720.0, S.y - 140.0), 70.0, "CHRG", Color(0.5, 1.0, 0.6)],
        "up": [Vector2(210.0, S.y - 560.0), 70.0, "UP", Color(1, 1, 1)],
        "down": [Vector2(430.0, S.y - 560.0), 70.0, "DOWN", Color(1, 1, 1)],
    }


func _hit_button(p):
    for k in layout:
        var b = layout[k]
        if p.distance_to(b[0]) <= b[1] * 1.15:
            return k
    return ""


func _set_stick(p):
    var v = p - stick_c
    if v.length() > stick_r:
        v = v.normalized() * stick_r
    stick = v / stick_r


func _tap_screen():
    if main.state == "title":
        main.start_match()
        return true
    if main.state == "over":
        main.try_restart()
        return true
    return false


func _input(event):
    if main == null:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if _tap_screen():
                return
            var p = event.position
            var hit = _hit_button(p)
            if hit != "":
                touches[event.index] = hit
                held[hit] = true
                taps[hit] = true
            elif p.distance_to(stick_c) < stick_r * 1.8:
                touches[event.index] = "stick"
                _set_stick(p)
        else:
            if touches.has(event.index):
                var k = touches[event.index]
                if k == "stick":
                    stick = Vector2.ZERO
                else:
                    held[k] = false
                touches.erase(event.index)
    elif event is InputEventScreenDrag:
        if touches.get(event.index, "") == "stick":
            _set_stick(event.position)
    elif event is InputEventKey and not event.echo:
        if keymap.has(event.keycode):
            var n = keymap[event.keycode]
            held[n] = event.pressed
            if event.pressed:
                if _tap_screen():
                    return
                taps[n] = true


func _process(_delta):
    _layout()
    if not touches.values().has("stick"):
        var kb = Vector2.ZERO
        if Input.is_key_pressed(KEY_A):
            kb.x -= 1.0
        if Input.is_key_pressed(KEY_D):
            kb.x += 1.0
        if Input.is_key_pressed(KEY_W):
            kb.y -= 1.0
        if Input.is_key_pressed(KEY_S):
            kb.y += 1.0
        if kb.length() > 0.1:
            stick = kb.normalized()
        else:
            stick = Vector2.ZERO
    queue_redraw()
    taps.clear()


func _text_c(font, text, pos, size, col):
    var w = 2000.0
    var p = Vector2(pos.x - w * 0.5, pos.y)
    draw_string_outline(font, p, text, HORIZONTAL_ALIGNMENT_CENTER, w, size, 14, Color(0, 0, 0, 0.9))
    draw_string(font, p, text, HORIZONTAL_ALIGNMENT_CENTER, w, size, col)


func _blink():
    return fmod(Time.get_ticks_msec() / 1000.0, 1.0) < 0.6


func _quad(x, y, w, h, mirror):
    var sk = h * 0.5
    if mirror:
        return PackedVector2Array([Vector2(x, y), Vector2(x + w, y), Vector2(x + w - sk, y + h), Vector2(x - sk, y + h)])
    return PackedVector2Array([Vector2(x + sk, y), Vector2(x + w + sk, y), Vector2(x + w, y + h), Vector2(x, y + h)])


func _bar(x, y, w, h, frac, col, mirror):
    draw_colored_polygon(_quad(x, y, w, h, mirror), Color(0, 0, 0, 0.55))
    var fw = w * clamp(frac, 0.0, 1.0)
    if fw > 2.0:
        var fx = x
        if mirror:
            fx = x + w - fw
        draw_colored_polygon(_quad(fx, y, fw, h, mirror), col)


func _fighter_hud(font, f, x, mirror):
    var w = 720.0
    var al = HORIZONTAL_ALIGNMENT_LEFT
    if mirror:
        al = HORIZONTAL_ALIGNMENT_RIGHT
    draw_string(font, Vector2(x, 56), f.fighter_name, al, w, 38, Color(1, 1, 1))
    var hf = clamp(f.hp / f.max_hp, 0.0, 1.0)
    _bar(x, 66, w, 34, hf, Color.from_hsv(0.33 * hf, 0.8, 1.0), mirror)
    var kw = w * 0.75
    var kx = x
    if mirror:
        kx = x + w - kw
    _bar(kx, 106, kw, 16, f.ki / 100.0, Color(0.3, 0.8, 1.0), mirror)
    var sw = w * 0.55
    var sx = x
    if mirror:
        sx = x + w - sw
    if f.spark_time > 0.0:
        _bar(sx, 128, sw, 12, f.spark_time / 14.0, Color(1.0, 0.85, 0.2), mirror)
    elif f.spark >= 100.0:
        var c = Color(1.0, 0.85, 0.2)
        if not _blink():
            c = Color(1.0, 1.0, 0.7)
        _bar(sx, 128, sw, 12, 1.0, c, mirror)
    else:
        _bar(sx, 128, sw, 12, f.spark / 100.0, Color(0.9, 0.55, 0.15), mirror)


func _speed_lines(S):
    var c = S * 0.5
    var t = Time.get_ticks_msec() / 1000.0
    for i in 40:
        var a = float(i) / 40.0 * TAU + sin(float(i) * 7.3) * 0.08
        var d = Vector2(cos(a), sin(a))
        var r0 = S.y * (0.42 + 0.2 * fmod(float(i) * 0.618 + t * 3.0, 1.0))
        draw_line(c + d * r0, c + d * (r0 + S.y * 0.45), Color(1, 1, 1, 0.4 * main.speed_fx), 4.0)


func _draw_controls(font):
    draw_circle(stick_c, stick_r, Color(1, 1, 1, 0.1))
    draw_arc(stick_c, stick_r, 0.0, TAU, 64, Color(1, 1, 1, 0.5), 5.0)
    draw_circle(stick_c + stick * stick_r, 70.0, Color(1, 1, 1, 0.4))
    var pl = main.player
    for k in layout:
        var b = layout[k]
        var col = b[3]
        var a = 0.22
        if held.get(k, false):
            a = 0.55
        var dim = false
        if k == "ult" and pl.ki < 60.0:
            dim = true
        if k == "spark" and pl.spark < 100.0:
            dim = true
        var r = b[1]
        if k == "spark" and pl.spark >= 100.0 and pl.spark_time <= 0.0:
            r += 6.0 * sin(Time.get_ticks_msec() / 120.0)
            a = 0.5
        var ring = 0.9
        if dim:
            a = 0.08
            ring = 0.3
        draw_circle(b[0], r, Color(col.r, col.g, col.b, a))
        draw_arc(b[0], r, 0.0, TAU, 48, Color(col.r, col.g, col.b, ring), 5.0)
        var fs = 40
        if k == "atk":
            fs = 54
        var tc = Color(1, 1, 1, 0.95)
        if dim:
            tc = Color(1, 1, 1, 0.35)
        draw_string(font, b[0] + Vector2(-b[1], fs * 0.35), b[2], HORIZONTAL_ALIGNMENT_CENTER, b[1] * 2.0, fs, tc)


func _draw():
    if main == null:
        return
    var S = get_viewport_rect().size
    var font = ThemeDB.fallback_font
    if main.state == "title":
        _text_c(font, "ZERO BURST", Vector2(S.x * 0.5, S.y * 0.45), 190, Color(1.0, 0.85, 0.25))
        _text_c(font, "SPARKING AIR BATTLE", Vector2(S.x * 0.5, S.y * 0.45 + 90), 56, Color(0.8, 0.9, 1.0))
        if _blink():
            _text_c(font, "TAP TO START", Vector2(S.x * 0.5, S.y * 0.85), 80, Color(1, 1, 1))
        return
    if main.speed_fx > 0.05:
        _speed_lines(S)
    _fighter_hud(font, main.player, 120.0, false)
    _fighter_hud(font, main.enemy, S.x - 120.0 - 720.0, true)
    if main.player.combo >= 2:
        _text_c(font, str(main.player.combo) + " HITS", Vector2(S.x * 0.5, S.y * 0.32), 90, Color(1.0, 0.9, 0.4))
    if main.player.spark_time > 0.0:
        _text_c(font, "SPARKING!", Vector2(S.x * 0.5, 190), 56, Color(1.0, 0.85, 0.2))
    if main.state == "fight":
        _draw_controls(font)
        if main.banner_t > 0.0:
            _text_c(font, main.banner, Vector2(S.x * 0.5, S.y * 0.45), 220, Color(1, 1, 1))
    elif main.state == "over":
        var c = Color(1.0, 0.85, 0.25)
        if main.result == "DEFEAT":
            c = Color(1.0, 0.3, 0.3)
        _text_c(font, main.result, Vector2(S.x * 0.5, S.y * 0.48), 230, c)
        if main.over_t > 1.5 and _blink():
            _text_c(font, "TAP FOR REMATCH", Vector2(S.x * 0.5, S.y * 0.82), 72, Color(1, 1, 1))
