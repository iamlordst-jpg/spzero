extends Control

var main
var stick = Vector2.ZERO
var held = {}
var taps = {}
var touches = {}
var layout = {}
var stick_c = Vector2(300, 640)
var stick_r = 150.0
var inset_l = 40.0
var inset_r = 40.0
var f_bold
var f_title
var lag_p = 1.0
var lag_e = 1.0
var popups = []
var combo_pop = 0.0
var last_combo = 0
var keymap = {KEY_J: "atk", KEY_K: "blast", KEY_L: "ult", KEY_SPACE: "dash", KEY_C: "charge", KEY_V: "spark", KEY_E: "up", KEY_Q: "down"}


func _ready():
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    f_bold = FontVariation.new()
    f_bold.base_font = ThemeDB.fallback_font
    f_bold.variation_embolden = 0.8
    f_title = FontVariation.new()
    f_title.base_font = ThemeDB.fallback_font
    f_title.variation_embolden = 1.1
    f_title.variation_transform = Transform2D(Vector2(1, 0), Vector2(-0.22, 1), Vector2.ZERO)


func held_btn(n):
    return held.get(n, false)


func tapped(n):
    if taps.get(n, false):
        taps[n] = false
        return true
    return false


func popup(pos, text, col, big):
    if popups.size() > 14:
        popups.pop_front()
    popups.append({"pos": pos, "text": text, "col": col, "age": 0.0, "big": big})


func _safe():
    var S = get_viewport_rect().size
    var win = Vector2(DisplayServer.window_get_size())
    var sa = DisplayServer.get_display_safe_area()
    var l = 40.0
    var r = 40.0
    if win.x > 0.0:
        var k = S.x / win.x
        l = max(l, sa.position.x * k)
        r = max(r, (win.x - sa.end.x) * k)
    return [l, r]


func _layout():
    var S = get_viewport_rect().size
    stick_c = Vector2(inset_l + 250.0, S.y - 235.0)
    var cx = S.x - inset_r - 190.0
    var cy = S.y - 205.0
    layout = {
        "atk": [Vector2(cx, cy), 105.0, "ATK", Color(1.0, 0.5, 0.2)],
        "blast": [Vector2(cx - 215.0, cy + 50.0), 80.0, "KI", Color(0.4, 0.85, 1.0)],
        "dash": [Vector2(cx - 170.0, cy - 165.0), 75.0, "DASH", Color(0.9, 0.92, 1.0)],
        "ult": [Vector2(cx - 10.0, cy - 250.0), 70.0, "ULT", Color(1.0, 0.3, 0.65)],
        "spark": [Vector2(cx - 400.0, cy - 150.0), 68.0, "SPARK", Color(1.0, 0.85, 0.2)],
        "charge": [Vector2(cx - 410.0, cy + 60.0), 65.0, "CHRG", Color(0.5, 1.0, 0.6)],
        "up": [Vector2(inset_l + 130.0, S.y - 500.0), 62.0, "UP", Color(1, 1, 1)],
        "down": [Vector2(inset_l + 300.0, S.y - 500.0), 62.0, "DOWN", Color(1, 1, 1)],
    }


func _hit_button(p):
    for k in layout:
        var b = layout[k]
        if p.distance_to(b[0]) <= b[1] * 1.15:
            return k
    return ""


func _set_stick(p):
    var v = p - stick_c
    if v.length() > stick_r:
        v = v.normalized() * stick_r
    stick = v / stick_r


func _tap_screen():
    if main.state == "title":
        main.start_match()
        return true
    if main.state == "over":
        main.try_restart()
        return true
    return false


func _input(event):
    if main == null:
        return
    if event is InputEventScreenTouch:
        if event.pressed:
            if _tap_screen():
                return
            var p = event.position
            var hit = _hit_button(p)
            if hit != "":
                touches[event.index] = hit
                held[hit] = true
                taps[hit] = true
            elif p.distance_to(stick_c) < stick_r * 1.8:
                touches[event.index] = "stick"
                _set_stick(p)
        else:
            if touches.has(event.index):
                var k = touches[event.index]
                if k == "stick":
                    stick = Vector2.ZERO
                else:
                    held[k] = false
                touches.erase(event.index)
    elif event is InputEventScreenDrag:
        if touches.get(event.index, "") == "stick":
            _set_stick(event.position)
    elif event is InputEventKey and not event.echo:
        if keymap.has(event.keycode):
            var n = keymap[event.keycode]
            held[n] = event.pressed
            if event.pressed:
                if _tap_screen():
                    return
                taps[n] = true


func _process(delta):
    var sa = _safe()
    inset_l = sa[0]
    inset_r = sa[1]
    _layout()
    if not touches.values().has("stick"):
        var kb = Vector2.ZERO
        if Input.is_key_pressed(KEY_A):
            kb.x -= 1.0
        if Input.is_key_pressed(KEY_D):
            kb.x += 1.0
        if Input.is_key_pressed(KEY_W):
            kb.y -= 1.0
        if Input.is_key_pressed(KEY_S):
            kb.y += 1.0
        if kb.length() > 0.1:
            stick = kb.normalized()
        else:
            stick = Vector2.ZERO
    if main != null and main.player != null:
        var fp = clamp(main.player.hp / main.player.max_hp, 0.0, 1.0)
        var fe = clamp(main.enemy.hp / main.enemy.max_hp, 0.0, 1.0)
        if lag_p > fp:
            lag_p = max(fp, lag_p - delta * 0.25)
        else:
            lag_p = fp
        if lag_e > fe:
            lag_e = max(fe, lag_e - delta * 0.25)
        else:
            lag_e = fe
        if main.player.combo != last_combo:
            if main.player.combo > last_combo:
                combo_pop = 1.0
            last_combo = main.player.combo
        combo_pop = max(0.0, combo_pop - delta * 4.0)
    for p in popups:
        p["age"] += delta
    popups = popups.filter(func(q): return q["age"] < 0.9)
    queue_redraw()
    taps.clear()


# ---------- drawing helpers ----------

func _txt(font, text, pos, size, col, align = HORIZONTAL_ALIGNMENT_LEFT, width = -1.0, outline = 8):
    draw_string_outline(font, pos, text, align, width, size, outline, Color(0, 0, 0, 0.85))
    draw_string(font, pos, text, align, width, size, col)


func _txt_c(font, text, pos, size, col, outline = 10):
    var w = 2000.0
    _txt(font, text, Vector2(pos.x - w * 0.5, pos.y), size, col, HORIZONTAL_ALIGNMENT_CENTER, w, outline)


func _blink():
    return fmod(Time.get_ticks_msec() / 1000.0, 1.0) < 0.6


func _para(x, y, w, h, sk):
    return PackedVector2Array([Vector2(x + sk, y), Vector2(x + w + sk, y), Vector2(x + w, y + h), Vector2(x, y + h)])


func _vignette(S, a):
    var c = Color(1, 0.1, 0.1, a)
    var t = Color(1, 0.1, 0.1, 0.0)
    var m = 220.0
    draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(S.x, 0), Vector2(S.x, m), Vector2(0, m)]), PackedColorArray([c, c, t, t]))
    draw_polygon(PackedVector2Array([Vector2(0, S.y - m), Vector2(S.x, S.y - m), Vector2(S.x, S.y), Vector2(0, S.y)]), PackedColorArray([t, t, c, c]))
    draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(m, 0), Vector2(m, S.y), Vector2(0, S.y)]), PackedColorArray([c, t, t, c]))
    draw_polygon(PackedVector2Array([Vector2(S.x - m, 0), Vector2(S.x, 0), Vector2(S.x, S.y), Vector2(S.x - m, S.y)]), PackedColorArray([t, c, c, t]))


func _speed_lines(S):
    var c = S * 0.5
    var t = Time.get_ticks_msec() / 1000.0
    for i in 40:
        var a = float(i) / 40.0 * TAU + sin(float(i) * 7.3) * 0.08
        var d = Vector2(cos(a), sin(a))
        var r0 = S.y * (0.42 + 0.2 * fmod(float(i) * 0.618 + t * 3.0, 1.0))
        draw_line(c + d * r0, c + d * (r0 + S.y * 0.45), Color(1, 1, 1, 0.4 * main.speed_fx), 4.0)


func _portrait(c, r, f):
    draw_circle(c, r + 7.0, Color(0, 0, 0, 0.6))
    draw_circle(c, r, Color(0.07, 0.09, 0.18, 0.95))
    var hc = f.hair_now
    for i in 5:
        var a = -PI * 0.5 + (i - 2) * 0.45
        var dir = Vector2(cos(a), sin(a))
        var perp = Vector2(-dir.y, dir.x)
        var base = c + dir * r * 0.42
        var tip = c + dir * r * (1.2 + 0.12 * float(i % 2))
        draw_colored_polygon(PackedVector2Array([base + perp * r * 0.24, tip, base - perp * r * 0.24]), hc)
    draw_circle(c + Vector2(0, -r * 0.16), r * 0.52, hc)
    draw_circle(c + Vector2(0, r * 0.12), r * 0.55, f.skin_col)
    for sx in [-1.0, 1.0]:
        var ex = c + Vector2(sx * r * 0.22, r * 0.1)
        draw_rect(Rect2(ex - Vector2(r * 0.1, r * 0.045), Vector2(r * 0.2, r * 0.09)), Color(1, 1, 1))
        draw_circle(ex, r * 0.04, f.base_aura)
        draw_line(ex + Vector2(-sx * r * 0.12, -r * 0.14 - sx * 0.0), ex + Vector2(sx * r * 0.12, -r * 0.08), hc, 5.0)
    draw_arc(c, r, 0.0, TAU, 48, f.base_aura, 6.0)


func _fighter_block(f, left, lag):
    var S = get_viewport_rect().size
    var w = 600.0
    var h = 34.0
    var dir = 1.0
    if not left:
        dir = -1.0
    var sk = h * 0.45 * dir
    var px = inset_l + 90.0
    var bx = px + 70.0
    if not left:
        px = S.x - inset_r - 90.0
        bx = px - 70.0 - w
    var by = 62.0
    _portrait(Vector2(px, 100.0), 62.0, f)
    var al = HORIZONTAL_ALIGNMENT_LEFT
    if not left:
        al = HORIZONTAL_ALIGNMENT_RIGHT
    _txt(f_title, f.fighter_name, Vector2(bx, 52.0), 42, Color(1, 1, 1), al, w, 8)
    draw_colored_polygon(_para(bx - 5, by - 5, w + 10, h + 10, sk), Color(0, 0, 0, 0.75))
    var frac = clamp(f.hp / f.max_hp, 0.0, 1.0)
    var lw = w * lag
    var lx = bx
    if not left:
        lx = bx + w - lw
    if lw > 2.0:
        draw_colored_polygon(_para(lx, by, lw, h, sk), Color(1, 1, 1, 0.85))
    var fw = w * frac
    var fx = bx
    if not left:
        fx = bx + w - fw
    if fw > 2.0:
        var base = Color.from_hsv(0.02 + 0.34 * frac, 0.8, 1.0)
        var lt = base.lightened(0.35)
        var dk = base.darkened(0.25)
        draw_polygon(_para(fx, by, fw, h, sk), PackedColorArray([lt, lt, dk, dk]))
    for i in range(1, 10):
        var tx = bx + w * float(i) / 10.0
        draw_line(Vector2(tx + sk, by), Vector2(tx, by + h), Color(0, 0, 0, 0.35), 2.0)
    var ky = by + h + 12.0
    var sw = (w * 0.78 - 9.0 * 6.0) / 10.0
    var kc = Color(0.35, 0.85, 1.0)
    if f.ki >= 60.0:
        kc = Color(0.7, 0.95, 1.0)
    for i in 10:
        var sx = bx + float(i) * (sw + 6.0)
        if not left:
            sx = bx + w - float(i + 1) * sw - float(i) * 6.0
        draw_colored_polygon(_para(sx, ky, sw, 14.0, sk * 0.4), Color(0, 0, 0, 0.6))
        var fill = clamp(f.ki / 10.0 - float(i), 0.0, 1.0)
        if fill > 0.02:
            var fxx = sx
            if not left:
                fxx = sx + sw * (1.0 - fill)
            draw_colored_polygon(_para(fxx, ky, sw * fill, 14.0, sk * 0.4), kc)
    var gy = ky + 24.0
    var gw = w * 0.6
    var gx = bx
    if not left:
        gx = bx + w - gw
    draw_colored_polygon(_para(gx, gy, gw, 11.0, sk * 0.3), Color(0, 0, 0, 0.6))
    var sf = f.spark / 100.0
    var gc = Color(0.95, 0.6, 0.15)
    if f.spark_time > 0.0:
        sf = f.spark_time / 14.0
        gc = Color(1.0, 0.9, 0.35)
    elif f.spark >= 100.0:
        sf = 1.0
        gc = Color(1.0, 0.9, 0.3)
        if not _blink():
            gc = Color(1.0, 1.0, 0.75)
    var gfw = gw * clamp(sf, 0.0, 1.0)
    var gfx = gx
    if not left:
        gfx = gx + gw - gfw
    if gfw > 2.0:
        draw_colored_polygon(_para(gfx, gy, gfw, 11.0, sk * 0.3), gc)


func _progress(k):
    var pl = main.player
    if k == "atk":
        return clamp(1.0 - pl.atk_cd / 0.3, 0.0, 1.0)
    if k == "blast":
        return clamp(pl.ki / 6.0, 0.0, 1.0)
    if k == "dash":
        return clamp(min(1.0 - pl.dash_cd / 0.35, pl.ki / 10.0), 0.0, 1.0)
    if k == "ult":
        return clamp(pl.ki / 60.0, 0.0, 1.0)
    if k == "spark":
        if pl.spark_time > 0.0:
            return clamp(pl.spark_time / 14.0, 0.0, 1.0)
        return clamp(pl.spark / 100.0, 0.0, 1.0)
    return 1.0


func _draw_controls():
    var t = Time.get_ticks_msec() / 1000.0
    draw_circle(stick_c, stick_r + 6.0, Color(0, 0, 0, 0.3))
    draw_circle(stick_c, stick_r, Color(0.05, 0.08, 0.15, 0.4))
    draw_arc(stick_c, stick_r, 0.0, TAU, 64, Color(1, 1, 1, 0.55), 5.0)
    for i in 8:
        var a = float(i) * PI * 0.25
        var d = Vector2(cos(a), sin(a))
        draw_line(stick_c + d * (stick_r - 22.0), stick_c + d * (stick_r - 6.0), Color(1, 1, 1, 0.5), 4.0)
    var kp = stick_c + stick * stick_r * 0.8
    draw_circle(kp, 64.0, Color(1, 1, 1, 0.3))
    draw_circle(kp, 46.0, Color(1, 1, 1, 0.45))
    var pl = main.player
    for k in layout:
        var b = layout[k]
        var c = b[0]
        var r = b[1]
        var col = b[3]
        var pr = _progress(k)
        var ready = pr >= 0.999
        var down = held.get(k, false)
        var pulse = 0.0
        if k == "spark" and pl.spark >= 100.0 and pl.spark_time <= 0.0:
            pulse = 0.5 + 0.5 * sin(t * 8.0)
        draw_circle(c, r + 6.0, Color(0, 0, 0, 0.35))
        draw_circle(c, r, Color(0.04, 0.06, 0.12, 0.55))
        if down:
            draw_circle(c, r, Color(col.r, col.g, col.b, 0.5))
        elif pulse > 0.0:
            draw_circle(c, r, Color(col.r, col.g, col.b, 0.15 + 0.3 * pulse))
        draw_arc(c, r - 4.0, 0.0, TAU, 48, Color(col.r, col.g, col.b, 0.25), 5.0)
        if pr > 0.01:
            var ra = 0.7
            if ready:
                ra = 1.0
            draw_arc(c, r - 4.0, -PI * 0.5, -PI * 0.5 + TAU * pr, 48, Color(col.r, col.g, col.b, ra), 8.0)
        var fs = 36
        if k == "atk":
            fs = 50
        var ta = 0.55
        if ready:
            ta = 1.0
        _txt_c(f_title, b[2], Vector2(c.x, c.y + fs * 0.33), fs, Color(1, 1, 1, ta), 6)


func _reticle():
    var cam = main.cam
    var e = main.enemy
    var wp = e.global_position + Vector3(0, 0.3, 0)
    if cam.is_position_behind(wp):
        return
    var sp = cam.unproject_position(wp)
    var d = main.player.global_position.distance_to(e.global_position)
    var col = Color(1, 1, 1, 0.85)
    if d < 4.0:
        col = Color(1.0, 0.35, 0.3, 0.95)
    var r = 70.0 + 6.0 * sin(Time.get_ticks_msec() / 150.0)
    var rot = Time.get_ticks_msec() / 1500.0
    for i in 4:
        var a = rot + float(i) * PI * 0.5
        draw_arc(sp, r, a - 0.35, a + 0.35, 8, col, 5.0)
    _txt(f_bold, "%.1f m" % d, Vector2(sp.x - 100.0, sp.y + r + 44.0), 30, col, HORIZONTAL_ALIGNMENT_CENTER, 200.0, 6)


func _draw_popups():
    var cam = main.cam
    for p in popups:
        var wp = p["pos"] + Vector3(0, p["age"] * 2.0, 0)
        if cam.is_position_behind(wp):
            continue
        var sp = cam.unproject_position(wp)
        var k = p["age"] / 0.9
        var a = 1.0 - k * k
        var sc = 1.0 + 0.5 * max(0.0, 1.0 - k * 6.0)
        var size = 58
        if p["big"]:
            size = 88
        var col = p["col"]
        _txt_c(f_title, p["text"], sp, int(size * sc), Color(col.r, col.g, col.b, a), 10)


func _draw_combo(S):
    var n = main.player.combo
    if n < 2:
        return
    var anchor = Vector2(S.x - inset_r - 40.0, S.y * 0.36)
    var sc = 1.0 + 0.45 * combo_pop
    draw_set_transform(anchor, 0.0, Vector2(sc, sc))
    _txt(f_title, str(n), Vector2(-400.0, 0.0), 130, Color(1.0, 0.9, 0.35), HORIZONTAL_ALIGNMENT_RIGHT, 400.0, 14)
    _txt(f_title, "HITS", Vector2(-400.0, 52.0), 52, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_RIGHT, 400.0, 10)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_banner(S):
    var u = 1.0 - main.banner_t / 1.4
    var a = clamp(min(u * 6.0, (1.0 - u) * 6.0), 0.0, 1.0)
    var cy = S.y * 0.42
    draw_rect(Rect2(0, cy - 110.0, S.x, 190.0), Color(0, 0, 0, 0.5 * a))
    draw_rect(Rect2(0, cy - 110.0, S.x, 6.0), Color(1.0, 0.85, 0.3, a))
    draw_rect(Rect2(0, cy + 74.0, S.x, 6.0), Color(1.0, 0.85, 0.3, a))
    var sc = 1.25 - 0.25 * clamp(u * 5.0, 0.0, 1.0)
    draw_set_transform(Vector2(S.x * 0.5, cy + 40.0), 0.0, Vector2(sc, sc))
    _txt_c(f_title, main.banner, Vector2(0, 0), 150, Color(1, 1, 1, a), 12)
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw():
    if main == null:
        return
    var S = get_viewport_rect().size
    if main.state == "title":
        draw_polygon(PackedVector2Array([Vector2(0, S.y * 0.5), Vector2(S.x, S.y * 0.5), Vector2(S.x, S.y), Vector2(0, S.y)]), PackedColorArray([Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.7), Color(0, 0, 0, 0.7)]))
        _txt_c(f_title, "ZERO BURST", Vector2(S.x * 0.5, S.y * 0.45), 200, Color(1.0, 0.88, 0.3), 16)
        draw_rect(Rect2(S.x * 0.5 - 520.0, S.y * 0.45 + 24.0, 1040.0, 6.0), Color(0.3, 0.8, 1.0))
        _txt_c(f_bold, "SPARKING AIR BATTLE", Vector2(S.x * 0.5, S.y * 0.45 + 100.0), 50, Color(0.85, 0.93, 1.0), 8)
        if _blink():
            _txt_c(f_title, "TOUCH TO START", Vector2(S.x * 0.5, S.y * 0.86), 76, Color(1, 1, 1), 10)
        return
    if main.speed_fx > 0.05:
        _speed_lines(S)
    var pl = main.player
    if pl.hp / pl.max_hp < 0.25 and main.state == "fight":
        _vignette(S, 0.2 + 0.15 * sin(Time.get_ticks_msec() / 150.0))
    _fighter_block(pl, true, lag_p)
    _fighter_block(main.enemy, false, lag_e)
    var cxm = S.x * 0.5
    draw_colored_polygon(PackedVector2Array([Vector2(cxm, 54.0), Vector2(cxm + 44.0, 98.0), Vector2(cxm, 142.0), Vector2(cxm - 44.0, 98.0)]), Color(0, 0, 0, 0.75))
    draw_polyline(PackedVector2Array([Vector2(cxm, 54.0), Vector2(cxm + 44.0, 98.0), Vector2(cxm, 142.0), Vector2(cxm - 44.0, 98.0), Vector2(cxm, 54.0)]), Color(1.0, 0.85, 0.3), 4.0)
    _txt_c(f_title, "VS", Vector2(cxm, 112.0), 40, Color(1, 1, 1), 6)
    if pl.spark_time > 0.0:
        _txt_c(f_title, "SPARKING!", Vector2(cxm, 200.0), 54, Color(1.0, 0.85, 0.2), 10)
    if main.state == "fight":
        _reticle()
        _draw_popups()
        _draw_combo(S)
        _draw_controls()
        if main.banner_t > 0.0:
            _draw_banner(S)
    elif main.state == "over":
        _draw_popups()
        var da = clamp(main.over_t, 0.0, 1.0) * 0.55
        draw_rect(Rect2(0, 0, S.x, S.y), Color(0, 0, 0, da))
        var c = Color(1.0, 0.88, 0.3)
        if main.result == "DEFEAT":
            c = Color(1.0, 0.3, 0.3)
        draw_rect(Rect2(0, S.y * 0.3, S.x, 6.0), Color(c.r, c.g, c.b, da * 1.5))
        draw_rect(Rect2(0, S.y * 0.62, S.x, 6.0), Color(c.r, c.g, c.b, da * 1.5))
        _txt_c(f_title, main.result, Vector2(S.x * 0.5, S.y * 0.54), 230, Color(c.r, c.g, c.b, clamp(main.over_t * 2.0, 0.0, 1.0)), 16)
        if main.over_t > 1.5 and _blink():
            _txt_c(f_title, "TAP FOR REMATCH", Vector2(S.x * 0.5, S.y * 0.84), 66, Color(1, 1, 1), 10)
    if main.flash > 0.01:
        draw_rect(Rect2(0, 0, S.x, S.y), Color(1, 1, 1, clamp(main.flash, 0.0, 1.0) * 0.7))
