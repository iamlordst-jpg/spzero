extends Node3D

const TOON = preload("res://shaders/toon.gdshader")
const OUTLINE = preload("res://shaders/outline.gdshader")
const AURA = preload("res://shaders/aura.gdshader")
const BlastScript = preload("res://blast.gd")

var main
var opp
var is_player = false
var fighter_name = ""
var speed_mul = 1.0
var dmg_mul = 1.0
var max_hp = 1000.0
var hp = 1000.0
var ki = 100.0
var spark = 0.0
var spark_time = 0.0
var vel = Vector3.ZERO
var stun = 0.0
var atk_cd = 0.0
var blast_cd = 0.0
var dash_t = 0.0
var dash_cd = 0.0
var dash_dir = Vector3.FORWARD
var dash_rush = false
var invuln = 0.0
var charging = false
var ult_t = 0.0
var ult_pending = false
var hit_t = 0.0
var combo = 0
var combo_t = 0.0
var swing = 0.0
var swing_side = 1
var pose_blast = 0.0
var anim_t = 0.0
var aura_i = 0.0
var base_aura = Color(0.4, 0.7, 1.0)
var hair_col = Color.BLACK
var model
var hair_mat
var aura_mat
var aura_mesh
var particles
var pmat
var arm_l
var arm_r
var leg_l
var leg_r
var ai_t = 0.0
var ai_mode = "approach"
var ai_strafe = 1.0


static func make_toon(col, outline_w = 0.025):
    var m = ShaderMaterial.new()
    m.shader = TOON
    m.set_shader_parameter("albedo", col)
    if outline_w > 0.0:
        var o = ShaderMaterial.new()
        o.shader = OUTLINE
        o.set_shader_parameter("thickness", outline_w)
        m.next_pass = o
    return m


func _part(parent, mesh, pos, mat, rot = Vector3.ZERO, scl = Vector3.ONE):
    var mi = MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.rotation_degrees = rot
    mi.scale = scl
    mi.material_override = mat
    parent.add_child(mi)
    return mi


func _capsule(r, h):
    var c = CapsuleMesh.new()
    c.radius = r
    c.height = h
    c.radial_segments = 24
    c.rings = 8
    return c


func _sphere(r):
    var s = SphereMesh.new()
    s.radius = r
    s.height = r * 2.0
    s.radial_segments = 24
    s.rings = 12
    return s


func _cyl(rt, rb, h):
    var c = CylinderMesh.new()
    c.top_radius = rt
    c.bottom_radius = rb
    c.height = h
    c.radial_segments = 20
    return c


func _build_arm(pivot, skin_m, trim_m):
    _part(pivot, _sphere(0.15), Vector3.ZERO, skin_m)
    _part(pivot, _capsule(0.105, 0.8), Vector3(0, -0.34, 0), skin_m)
    _part(pivot, _cyl(0.118, 0.118, 0.12), Vector3(0, -0.55, 0), trim_m)
    _part(pivot, _sphere(0.12), Vector3(0, -0.78, 0), skin_m)


func _build_leg(pivot, gi_m, trim_m):
    _part(pivot, _capsule(0.14, 0.95), Vector3(0, -0.45, 0), gi_m)
    _part(pivot, _capsule(0.16, 0.34), Vector3(0, -0.86, -0.04), trim_m)


func setup(m, player_flag, nm, skin, hair, gi, trim, aura):
    main = m
    is_player = player_flag
    fighter_name = nm
    base_aura = aura
    hair_col = hair
    model = Node3D.new()
    add_child(model)
    var skin_m = make_toon(skin)
    var gi_m = make_toon(gi)
    var trim_m = make_toon(trim)
    hair_mat = make_toon(hair, 0.03)

    _part(model, _capsule(0.3, 1.0), Vector3(0, 0.45, 0), gi_m, Vector3.ZERO, Vector3(1.2, 1.0, 0.78))
    _part(model, _cyl(0.28, 0.28, 0.14), Vector3(0, 0.05, 0), trim_m, Vector3.ZERO, Vector3(1.2, 1.0, 0.8))
    _part(model, _cyl(0.09, 0.09, 0.16), Vector3(0, 1.0, 0), skin_m)
    _part(model, _sphere(0.24), Vector3(0, 1.2, 0), skin_m, Vector3.ZERO, Vector3(1.0, 1.05, 1.0))

    var eye_m = StandardMaterial3D.new()
    eye_m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    eye_m.albedo_color = Color(1, 1, 1)
    var pupil_m = StandardMaterial3D.new()
    pupil_m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    pupil_m.albedo_color = aura
    for sx in [-0.09, 0.09]:
        _part(model, _sphere(0.045), Vector3(sx, 1.22, -0.2), eye_m, Vector3.ZERO, Vector3(1.0, 0.7, 0.5))
        _part(model, _sphere(0.024), Vector3(sx, 1.22, -0.222), pupil_m)

    var hair_pieces = [
        [Vector3(0, 1.52, 0.0), Vector3(0, 0, 0), 0.55],
        [Vector3(-0.13, 1.47, -0.03), Vector3(0, 0, 28), 0.5],
        [Vector3(0.13, 1.47, -0.03), Vector3(0, 0, -28), 0.5],
        [Vector3(-0.21, 1.36, 0.02), Vector3(0, 0, 55), 0.45],
        [Vector3(0.21, 1.36, 0.02), Vector3(0, 0, -55), 0.45],
        [Vector3(0, 1.47, 0.14), Vector3(35, 0, 0), 0.55],
        [Vector3(-0.12, 1.42, 0.12), Vector3(30, 0, 25), 0.5],
        [Vector3(0.12, 1.42, 0.12), Vector3(30, 0, -25), 0.5],
        [Vector3(0, 1.43, -0.17), Vector3(-35, 0, 0), 0.38],
        [Vector3(-0.1, 1.4, -0.17), Vector3(-30, 0, 20), 0.34],
        [Vector3(0.1, 1.4, -0.17), Vector3(-30, 0, -20), 0.34],
    ]
    for hpc in hair_pieces:
        var c = CylinderMesh.new()
        c.top_radius = 0.0
        c.bottom_radius = 0.13
        c.height = hpc[2]
        c.radial_segments = 12
        _part(model, c, hpc[0], hair_mat, hpc[1])

    arm_r = Node3D.new()
    arm_r.position = Vector3(0.52, 0.8, 0.0)
    model.add_child(arm_r)
    _build_arm(arm_r, skin_m, trim_m)
    arm_l = Node3D.new()
    arm_l.position = Vector3(-0.52, 0.8, 0.0)
    model.add_child(arm_l)
    _build_arm(arm_l, skin_m, trim_m)
    leg_r = Node3D.new()
    leg_r.position = Vector3(0.16, -0.05, 0.0)
    model.add_child(leg_r)
    _build_leg(leg_r, gi_m, trim_m)
    leg_l = Node3D.new()
    leg_l.position = Vector3(-0.16, -0.05, 0.0)
    model.add_child(leg_l)
    _build_leg(leg_l, gi_m, trim_m)

    aura_mat = ShaderMaterial.new()
    aura_mat.shader = AURA
    aura_mat.set_shader_parameter("aura_color", aura)
    aura_mat.set_shader_parameter("intensity", 0.0)
    aura_mesh = _part(self, _capsule(0.95, 3.0), Vector3(0, 0.3, 0), aura_mat)
    aura_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    aura_mesh.visible = false

    particles = CPUParticles3D.new()
    particles.amount = 40
    particles.lifetime = 0.8
    particles.emitting = false
    particles.local_coords = false
    particles.direction = Vector3.UP
    particles.spread = 15.0
    particles.initial_velocity_min = 3.0
    particles.initial_velocity_max = 6.0
    particles.gravity = Vector3.ZERO
    particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    particles.emission_sphere_radius = 0.7
    particles.scale_amount_min = 0.6
    particles.scale_amount_max = 1.6
    particles.mesh = main.make_dot_mesh(Color(aura.r * 2.5, aura.g * 2.5, aura.b * 2.5), 0.05)
    pmat = particles.mesh.material
    add_child(particles)


func set_hair(c, g):
    hair_mat.set_shader_parameter("albedo", c)
    hair_mat.set_shader_parameter("glow_color", c)
    hair_mat.set_shader_parameter("glow_energy", g)


func reset(pos):
    position = pos
    hp = max_hp
    ki = 100.0
    spark = 0.0
    spark_time = 0.0
    vel = Vector3.ZERO
    stun = 0.0
    atk_cd = 0.0
    blast_cd = 0.0
    dash_t = 0.0
    dash_cd = 0.0
    dash_rush = false
    invuln = 0.0
    charging = false
    ult_t = 0.0
    ult_pending = false
    hit_t = 0.0
    combo = 0
    swing = 0.0
    pose_blast = 0.0
    aura_i = 0.0
    ai_t = 0.5
    ai_mode = "approach"
    set_hair(hair_col, 0.0)
    model.rotation = Vector3.ZERO
    model.position = Vector3.ZERO
    arm_r.rotation = Vector3(0, 0, 0.17)
    arm_l.rotation = Vector3(0, 0, -0.17)


func snap_face():
    var f = _flat_to_opp()
    model.rotation.y = atan2(-f.x, -f.z)


func _flat_to_opp():
    var d = opp.position - position
    d.y = 0.0
    if d.length() < 0.01:
        return Vector3(0, 0, -1)
    return d.normalized()


func _process(delta):
    anim_t += delta
    if main.state != "fight":
        _idle(delta)
        return
    _timers(delta)
    if hp > 0.0:
        if stun <= 0.0 and ult_t <= 0.0:
            if is_player:
                _player_control(delta)
            else:
                _ai(delta)
        elif ult_t > 0.0:
            vel = vel.lerp(Vector3.ZERO, 1.0 - exp(-10.0 * delta))
        else:
            vel = vel.lerp(Vector3.ZERO, 1.0 - exp(-3.0 * delta))
    _move(delta)
    _visuals(delta)


func _idle(delta):
    charging = false
    model.position.y = sin(anim_t * 2.5) * 0.05
    aura_i = lerp(aura_i, 0.0, 1.0 - exp(-6.0 * delta))
    aura_mat.set_shader_parameter("intensity", aura_i)
    aura_mesh.visible = aura_i > 0.03
    particles.emitting = false
    if hp <= 0.0:
        vel.y -= 25.0 * delta
        position += vel * delta
        vel.x = lerp(vel.x, 0.0, 1.0 - exp(-2.0 * delta))
        vel.z = lerp(vel.z, 0.0, 1.0 - exp(-2.0 * delta))
        if position.y < 1.1:
            position.y = 1.1
            vel = Vector3.ZERO
        model.rotation.z = lerp(model.rotation.z, 1.4, 1.0 - exp(-4.0 * delta))
        return
    var f = _flat_to_opp()
    model.rotation.y = lerp_angle(model.rotation.y, atan2(-f.x, -f.z), 1.0 - exp(-8.0 * delta))
    model.rotation.x = lerp(model.rotation.x, 0.0, 1.0 - exp(-8.0 * delta))
    model.rotation.z = lerp(model.rotation.z, 0.0, 1.0 - exp(-8.0 * delta))


func _timers(delta):
    atk_cd = max(0.0, atk_cd - delta)
    blast_cd = max(0.0, blast_cd - delta)
    dash_cd = max(0.0, dash_cd - delta)
    invuln = max(0.0, invuln - delta)
    stun = max(0.0, stun - delta)
    pose_blast = max(0.0, pose_blast - delta)
    swing = max(0.0, swing - delta * 4.5)
    if combo_t > 0.0:
        combo_t -= delta
        if combo_t <= 0.0:
            combo = 0
    if dash_t > 0.0:
        dash_t -= delta
        if dash_t <= 0.0:
            vel = dash_dir * 6.0
    if hit_t > 0.0:
        hit_t -= delta
        if hit_t <= 0.0:
            _resolve_hit()
    if ult_t > 0.0:
        ult_t -= delta
        if ult_t <= 0.0 and ult_pending:
            ult_pending = false
            _fire_ult()
    if spark_time > 0.0:
        spark_time -= delta
        if spark_time <= 0.0:
            set_hair(hair_col, 0.0)
    var regen = 3.0
    if charging:
        regen = 32.0
    if spark_time > 0.0:
        regen += 12.0
    ki = clamp(ki + regen * delta, 0.0, 100.0)
    charging = false


func _player_control(delta):
    var h = main.hud
    var fwd = _flat_to_opp()
    var right = fwd.cross(Vector3.UP)
    var st = h.stick
    var want = fwd * (-st.y) + right * st.x
    var vert = 0.0
    if h.held_btn("up"):
        vert += 1.0
    if h.held_btn("down"):
        vert -= 1.0
    if h.held_btn("charge") and want.length() < 0.2:
        charging = true
    if h.tapped("atk"):
        do_attack()
    if h.held_btn("blast"):
        shoot_blast(0.0)
    if h.tapped("ult"):
        start_ult()
    if h.tapped("dash"):
        var d = want
        if d.length() < 0.2:
            d = right
            if randf() < 0.5:
                d = -right
        start_dash(d.normalized(), 0.18)
    if h.tapped("spark"):
        activate_spark()
    _apply_move(want, vert, delta)


func _ai(delta):
    ai_t -= delta
    var to = opp.position - position
    var dist = to.length()
    var fwd = _flat_to_opp()
    var right = fwd.cross(Vector3.UP)
    if ai_t <= 0.0:
        ai_t = randf_range(0.5, 1.3)
        ai_strafe = 1.0
        if randf() < 0.5:
            ai_strafe = -1.0
        var r = randf()
        if ki < 25.0 and r < 0.6:
            ai_mode = "charge"
        elif dist > 16.0:
            if r < 0.55:
                ai_mode = "approach"
            else:
                ai_mode = "blast"
        elif dist > 6.0:
            if r < 0.3:
                ai_mode = "blast"
            elif r < 0.55:
                ai_mode = "strafe"
            elif r < 0.8:
                ai_mode = "rush"
            else:
                ai_mode = "approach"
        else:
            if r < 0.55:
                ai_mode = "melee"
            elif r < 0.75:
                ai_mode = "strafe"
            elif r < 0.9:
                ai_mode = "retreat"
            else:
                ai_mode = "blast"
    var want = Vector3.ZERO
    if ai_mode == "approach":
        want = to.normalized()
    elif ai_mode == "strafe":
        want = right * ai_strafe + fwd * 0.2
    elif ai_mode == "retreat":
        want = -fwd + right * ai_strafe * 0.5
    elif ai_mode == "melee":
        if dist > 2.8:
            want = to.normalized()
        else:
            want = right * ai_strafe * 0.4
        if dist < 3.6 and randf() < 3.2 * delta:
            do_attack()
    elif ai_mode == "blast":
        want = right * ai_strafe * 0.6
        if randf() < 3.5 * delta:
            shoot_blast(0.12)
    elif ai_mode == "rush":
        if dist > 4.0:
            do_attack()
        ai_mode = "melee"
    elif ai_mode == "charge":
        charging = true
        if ki >= 90.0:
            ai_t = 0.0
    var vert = clamp((opp.position.y - position.y) * 0.4, -1.0, 1.0)
    if ai_mode == "strafe":
        vert += sin(anim_t * 1.5) * 0.5
    if charging:
        want = Vector3.ZERO
        vert = 0.0
    if ki >= 70.0 and dist > 5.0 and randf() < 0.25 * delta:
        start_ult()
    if spark >= 100.0:
        activate_spark()
    if dash_cd <= 0.0:
        for b in get_tree().get_nodes_in_group("blasts"):
            if b.shooter != self and global_position.distance_to(b.global_position) < 7.0 and randf() < 2.5 * delta:
                start_dash(right * ai_strafe, 0.18)
                break
    _apply_move(want, vert, delta)


func _apply_move(want, vert, delta):
    if dash_t > 0.0:
        return
    var spd = 15.0 * speed_mul
    if spark_time > 0.0:
        spd *= 1.3
    var target = Vector3.ZERO
    if not charging:
        target = want.limit_length(1.0) * spd + Vector3.UP * vert * spd * 0.7
    vel = vel.lerp(target, 1.0 - exp(-7.0 * delta))


func _move(delta):
    if dash_t > 0.0:
        vel = dash_dir * 48.0
        if dash_rush and position.distance_to(opp.position) < 2.5:
            dash_t = 0.0
            dash_rush = false
            vel = dash_dir * 4.0
            atk_cd = 0.0
            do_attack()
    else:
        dash_rush = false
    position += vel * delta
    var flat = Vector2(position.x, position.z)
    if flat.length() > 85.0:
        flat = flat.normalized() * 85.0
        position.x = flat.x
        position.z = flat.y
    if position.y < 1.1:
        position.y = 1.1
        if vel.y < 0.0:
            vel.y = 0.0
    position.y = min(position.y, 50.0)
    var d = opp.position - position
    var dist = d.length()
    if dist < 1.4 and dist > 0.01:
        position -= d.normalized() * (1.4 - dist) * 0.5


func start_dash(dir, t):
    if dash_cd > 0.0 or ki < 10.0 or dir.length() < 0.01:
        return false
    ki -= 10.0
    dash_cd = 0.35
    dash_t = t
    dash_dir = dir.normalized()
    invuln = max(invuln, t + 0.05)
    if is_player:
        main.speed_fx = 0.8
    return true


func do_attack():
    if atk_cd > 0.0 or hit_t > 0.0:
        return
    var to = opp.position - position
    if to.length() > 3.8:
        if start_dash(to, 0.3):
            dash_rush = true
            atk_cd = 0.3
        return
    atk_cd = 0.3
    hit_t = 0.1
    swing = 1.0
    swing_side = -swing_side
    vel = to.normalized() * 7.0


func _resolve_hit():
    if stun > 0.0 or hp <= 0.0 or opp.hp <= 0.0:
        return
    var to = opp.position - position
    if to.length() > 4.4:
        combo = 0
        return
    combo += 1
    combo_t = 1.1
    var heavy = combo >= 5
    var dmg = 36.0 * dmg_mul
    if spark_time > 0.0:
        dmg *= 1.5
    var knock = 5.0
    if heavy:
        dmg *= 1.8
        knock = 30.0
        combo = 0
    var ok = opp.take_hit(dmg, to.normalized(), knock, heavy)
    if ok:
        ki = min(100.0, ki + 4.0)


func shoot_blast(spread):
    if blast_cd > 0.0 or ki < 6.0:
        return
    ki -= 6.0
    blast_cd = 0.2
    pose_blast = 0.3
    var dir = (opp.position + Vector3(0, 0.2, 0) - position).normalized()
    if spread > 0.0:
        dir = (dir + Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * spread).normalized()
    var dmg = 28.0 * dmg_mul
    var col = base_aura
    if spark_time > 0.0:
        dmg *= 1.4
        col = Color(1.0, 0.85, 0.3)
    _spawn_blast(dir, dmg, 0.35, 34.0, 1.2, col, false)


func start_ult():
    if ult_t > 0.0 or ki < 60.0 or stun > 0.0:
        return
    ki -= 60.0
    ult_t = 0.75
    ult_pending = true
    main.shake = max(main.shake, 0.15)


func _fire_ult():
    var dir = (opp.position + Vector3(0, 0.2, 0) - position).normalized()
    var dmg = 190.0 * dmg_mul
    var col = base_aura
    if spark_time > 0.0:
        dmg *= 1.3
        col = Color(1.0, 0.85, 0.3)
    _spawn_blast(dir, dmg, 1.3, 26.0, 0.9, col, true)
    main.shake = 0.5
    pose_blast = 0.6


func _spawn_blast(dir, dmg, radius, spd, hom, col, big):
    var b = BlastScript.new()
    b.setup(main, self, opp, dmg, col, radius, spd, hom, big)
    main.add_child(b)
    b.global_position = global_position + dir * 1.3 + Vector3(0, 0.2, 0)
    b.vel = dir * spd


func activate_spark():
    if spark < 100.0 or spark_time > 0.0:
        return
    spark = 0.0
    spark_time = 14.0
    hp = min(max_hp, hp + 120.0)
    ki = 100.0
    set_hair(Color(1.0, 0.82, 0.2), 0.8)
    main.shake = 0.6
    main.hitstop = max(main.hitstop, 0.1)
    main.spawn_explosion(global_position, Color(1.0, 0.8, 0.2), 6.0)


func take_hit(dmg, dir, knock, heavy = false):
    if invuln > 0.0 or hp <= 0.0:
        return false
    hp = max(0.0, hp - dmg)
    vel = dir * knock
    if heavy:
        stun = 0.5
    else:
        stun = 0.2
    hit_t = 0.0
    ult_pending = false
    ult_t = 0.0
    dash_t = 0.0
    dash_rush = false
    combo = 0
    spark = min(100.0, spark + dmg * 0.07)
    opp.spark = min(100.0, opp.spark + dmg * 0.04)
    main.spawn_hit_fx(global_position + Vector3(0, 0.3, 0), heavy)
    if heavy:
        main.shake = max(main.shake, 0.4)
        main.hitstop = max(main.hitstop, 0.08)
    else:
        main.shake = max(main.shake, 0.12)
        main.hitstop = max(main.hitstop, 0.03)
    if hp <= 0.0:
        main.on_ko(self)
    return true


func _visuals(delta):
    var f = _flat_to_opp()
    model.rotation.y = lerp_angle(model.rotation.y, atan2(-f.x, -f.z), 1.0 - exp(-14.0 * delta))
    var side_dir = f.cross(Vector3.UP)
    var lean = clamp(vel.dot(f) / 30.0, -0.3, 1.0) * 0.9
    var roll = clamp(vel.dot(side_dir) / 20.0, -1.0, 1.0) * 0.3
    model.rotation.x = lerp(model.rotation.x, -lean, 1.0 - exp(-10.0 * delta))
    model.rotation.z = lerp(model.rotation.z, -roll, 1.0 - exp(-10.0 * delta))
    model.position.y = sin(anim_t * 2.5) * 0.05

    var blast_a = 0.0
    if pose_blast > 0.0:
        blast_a = 1.45
    var out = 0.17
    if charging or ult_t > 0.0:
        out = 0.77
    var pr = 0.0
    var pl = 0.0
    if swing_side > 0:
        pr = swing * 1.7
    else:
        pl = swing * 1.7
    arm_r.rotation.x = pr + blast_a
    arm_l.rotation.x = pl + blast_a
    arm_r.rotation.z = out
    arm_l.rotation.z = -out
    var sway = sin(anim_t * 3.0) * 0.12
    var trail = clamp(vel.length() / 20.0, 0.0, 1.0) * 0.5
    leg_r.rotation.x = sway - trail
    leg_l.rotation.x = -sway - trail

    var target_i = 0.0
    if charging:
        target_i = 1.0
    if ult_t > 0.0:
        target_i = 1.5
    if spark_time > 0.0:
        target_i = max(target_i, 0.8)
    if dash_t > 0.0:
        target_i = max(target_i, 0.7)
    aura_i = lerp(aura_i, target_i, 1.0 - exp(-10.0 * delta))
    var ac = base_aura
    if spark_time > 0.0:
        ac = Color(1.0, 0.82, 0.25)
    aura_mat.set_shader_parameter("aura_color", ac)
    aura_mat.set_shader_parameter("intensity", aura_i)
    aura_mesh.visible = aura_i > 0.03
    aura_mesh.scale = Vector3.ONE * (1.0 + 0.04 * sin(anim_t * 20.0)) * (1.0 + 0.3 * clamp(aura_i - 1.0, 0.0, 1.0))
    particles.emitting = aura_i > 0.4
    pmat.albedo_color = Color(ac.r * 2.5, ac.g * 2.5, ac.b * 2.5)
