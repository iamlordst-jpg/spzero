extends Node3D

const AURA = preload("res://shaders/aura.gdshader")
const BlastScript = preload("res://blast.gd")
const CLIP_KEYS = {
    "idle": ["idle"],
    "move": ["fly", "sprint", "jog", "run", "walk"],
    "punch": ["punch", "attack", "jab", "kick", "slash"],
    "blast": ["shoot", "cast", "spell", "throw"],
    "hurt": ["hit", "hurt", "damage", "impact"],
    "charge": ["charge", "power", "taunt", "spell_simple_idle", "idle"],
    "dash": ["dash", "dodge", "roll", "dive"],
    "ko": ["death", "die", "dead", "ko"],
}

var main
var opp
var is_player = false
var fighter_name = ""
var speed_mul = 1.0
var dmg_mul = 1.0
var max_hp = 1000.0
var hp = 1000.0
var ki = 100.0
var spark = 0.0
var spark_time = 0.0
var vel = Vector3.ZERO
var stun = 0.0
var atk_cd = 0.0
var blast_cd = 0.0
var dash_t = 0.0
var dash_cd = 0.0
var dash_dir = Vector3.FORWARD
var dash_rush = false
var invuln = 0.0
var charging = false
var ult_t = 0.0
var ult_pending = false
var hit_t = 0.0
var combo = 0
var combo_t = 0.0
var swing = 0.0
var swing_side = 1
var attack_n = 0
var kick = false
var pose_blast = 0.0
var anim_t = 0.0
var aura_i = 0.0
var base_aura = Color(0.4, 0.7, 1.0)
var skin_col = Color.WHITE
var hair_col = Color.BLACK
var hair_now = Color.BLACK
var model
var hair_mat
var hair_node
var aura_mat
var aura_mesh
var aura_core_mat
var aura_core
var particles
var pmat
var arm_l
var arm_r
var leg_l
var leg_r
var body
var elbow_r
var elbow_l
var knee_r
var knee_l
var sm_er = 0.5
var sm_el = 0.5
var cape_a
var cape_b
var sm_pr = 0.0
var sm_pl = 0.0
var sm_out = 0.17
var charge_fx_t = 0.0
var dust_t = 0.0
var ai_t = 0.0
var ai_mode = "approach"
var ai_strafe = 1.0
var ext
var anim
var anim_cur = ""
var last_side = 1
var clips = {}


static func make_pbr(col, metal = 0.0, rough = 0.7, rim = 0.0):
    var m = StandardMaterial3D.new()
    m.albedo_color = col
    m.metallic = metal
    m.roughness = rough
    if rim > 0.0:
        m.rim_enabled = true
        m.rim = rim
        m.rim_tint = 0.5
    return m


func _part(parent, mesh, pos, mat, rot = Vector3.ZERO, scl = Vector3.ONE):
    var mi = MeshInstance3D.new()
    mi.mesh = mesh
    mi.position = pos
    mi.rotation_degrees = rot
    mi.scale = scl
    mi.material_override = mat
    parent.add_child(mi)
    return mi


func _capsule(r, h):
    var c = CapsuleMesh.new()
    c.radius = r
    c.height = h
    c.radial_segments = 24
    c.rings = 8
    return c


func _sphere(r):
    var s = SphereMesh.new()
    s.radius = r
    s.height = r * 2.0
    s.radial_segments = 24
    s.rings = 12
    return s


func _cyl(rt, rb, h):
    var c = CylinderMesh.new()
    c.top_radius = rt
    c.bottom_radius = rb
    c.height = h
    c.radial_segments = 20
    return c


func _box(x, y, z):
    var b = BoxMesh.new()
    b.size = Vector3(x, y, z)
    return b


func _build_arm(pivot, skin_m, armor_m, dark_m):
    _part(pivot, _sphere(0.065), Vector3.ZERO, skin_m)
    _part(pivot, _capsule(0.052, 0.3), Vector3(0, -0.14, 0), skin_m)
    var elbow = Node3D.new()
    elbow.position = Vector3(0, -0.28, 0)
    pivot.add_child(elbow)
    _part(elbow, _sphere(0.048), Vector3.ZERO, skin_m)
    _part(elbow, _capsule(0.045, 0.28), Vector3(0, -0.13, 0), skin_m)
    _part(elbow, _cyl(0.058, 0.052, 0.13), Vector3(0, -0.2, 0), armor_m)
    _part(elbow, _sphere(0.055), Vector3(0, -0.3, 0), dark_m, Vector3.ZERO, Vector3(1.0, 1.1, 1.1))
    return elbow


func _build_leg(pivot, cloth_m, armor_m, dark_m):
    _part(pivot, _capsule(0.08, 0.5), Vector3(0, -0.22, 0), cloth_m)
    var knee = Node3D.new()
    knee.position = Vector3(0, -0.45, 0)
    pivot.add_child(knee)
    _part(knee, _sphere(0.062), Vector3(0, 0, -0.01), armor_m)
    _part(knee, _capsule(0.058, 0.5), Vector3(0, -0.22, 0), cloth_m)
    _part(knee, _capsule(0.07, 0.26), Vector3(0, -0.33, 0), dark_m)
    _part(knee, _capsule(0.05, 0.24), Vector3(0, -0.44, -0.06), dark_m, Vector3(90, 0, 0))
    return knee


func setup(m, player_flag, nm, skin, hair, gi, trim, aura, cape):
    main = m
    is_player = player_flag
    fighter_name = nm
    base_aura = aura
    skin_col = skin
    hair_col = hair
    hair_now = hair
    model = Node3D.new()
    add_child(model)
    body = Node3D.new()
    body.scale = Vector3.ONE * 1.2
    body.position = Vector3(0, 0.2, 0)
    model.add_child(body)

    var skin_m = make_pbr(skin, 0.0, 0.55, 0.35)
    var cloth_m = make_pbr(gi, 0.0, 0.8)
    var armor_m = make_pbr(trim, 0.65, 0.32)
    var dark_m = make_pbr(gi.darkened(0.35), 0.1, 0.6)
    var cape_m = make_pbr(cape, 0.0, 0.9)
    cape_m.cull_mode = BaseMaterial3D.CULL_DISABLED
    hair_mat = make_pbr(hair, 0.0, 0.35, 0.4)

    _part(body, _capsule(0.17, 0.42), Vector3(0, -0.05, 0), cloth_m, Vector3.ZERO, Vector3(1.25, 1.0, 0.9))
    _part(body, _capsule(0.15, 0.34), Vector3(0, 0.13, 0), cloth_m, Vector3.ZERO, Vector3(1.15, 1.0, 0.85))
    _part(body, _capsule(0.2, 0.44), Vector3(0, 0.38, 0), cloth_m, Vector3.ZERO, Vector3(1.3, 1.0, 0.85))
    _part(body, _capsule(0.205, 0.3), Vector3(0, 0.41, -0.01), armor_m, Vector3.ZERO, Vector3(1.32, 1.0, 0.9))
    _part(body, _cyl(0.17, 0.17, 0.07), Vector3(0, 0.02, 0), armor_m, Vector3.ZERO, Vector3(1.3, 1.0, 0.9))
    _part(body, _cyl(0.055, 0.065, 0.12), Vector3(0, 0.62, 0), skin_m)
    _part(body, _sphere(0.115), Vector3(0, 0.78, 0), skin_m, Vector3.ZERO, Vector3(0.92, 1.18, 1.0))
    _part(body, _sphere(0.122), Vector3(0, 0.81, 0.025), hair_mat, Vector3.ZERO, Vector3(0.97, 1.0, 1.0))
    for sx in [-1.0, 1.0]:
        _part(body, _sphere(0.095), Vector3(sx * 0.29, 0.6, 0), armor_m, Vector3.ZERO, Vector3(1.0, 0.7, 1.05))

    var eye_m = StandardMaterial3D.new()
    eye_m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    eye_m.albedo_color = Color(0.95, 0.95, 0.95)
    var pupil_m = StandardMaterial3D.new()
    pupil_m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    pupil_m.albedo_color = Color(aura.r * 1.3, aura.g * 1.3, aura.b * 1.3)
    for sx in [-0.045, 0.045]:
        _part(body, _sphere(0.02), Vector3(sx, 0.79, -0.108), eye_m, Vector3.ZERO, Vector3(1.0, 0.6, 0.5))
        _part(body, _sphere(0.012), Vector3(sx, 0.79, -0.117), pupil_m)
        _part(body, _box(0.05, 0.008, 0.01), Vector3(sx, 0.83, -0.106), hair_mat, Vector3(0, 0, sx * 300.0))

    hair_node = Node3D.new()
    hair_node.position = Vector3(0, 0.78, 0)
    body.add_child(hair_node)
    var hair_pieces = [
        [Vector3(0, 0.95, 0.01), Vector3(0, 0, 0), 0.28],
        [Vector3(-0.06, 0.93, 0.0), Vector3(0, 0, 22), 0.26],
        [Vector3(0.06, 0.93, 0.0), Vector3(0, 0, -22), 0.26],
        [Vector3(-0.1, 0.88, 0.02), Vector3(0, 0, 45), 0.22],
        [Vector3(0.1, 0.88, 0.02), Vector3(0, 0, -45), 0.22],
        [Vector3(0, 0.92, 0.08), Vector3(40, 0, 0), 0.3],
        [Vector3(-0.06, 0.9, 0.08), Vector3(35, 0, 20), 0.26],
        [Vector3(0.06, 0.9, 0.08), Vector3(35, 0, -20), 0.26],
        [Vector3(0, 0.84, 0.12), Vector3(65, 0, 0), 0.26],
        [Vector3(0, 0.92, -0.07), Vector3(-30, 0, 0), 0.2],
        [Vector3(-0.05, 0.91, -0.07), Vector3(-28, 0, 15), 0.18],
        [Vector3(0.05, 0.91, -0.07), Vector3(-28, 0, -15), 0.18],
        [Vector3(-0.12, 0.8, 0.04), Vector3(0, 0, 80), 0.16],
        [Vector3(0.12, 0.8, 0.04), Vector3(0, 0, -80), 0.16],
    ]
    for hpc in hair_pieces:
        var c = CylinderMesh.new()
        c.top_radius = 0.0
        c.bottom_radius = 0.05
        c.height = hpc[2]
        c.radial_segments = 12
        _part(hair_node, c, hpc[0] - Vector3(0, 0.78, 0), hair_mat, hpc[1])

    cape_a = Node3D.new()
    cape_a.position = Vector3(0, 0.57, 0.16)
    body.add_child(cape_a)
    _part(cape_a, _box(0.5, 0.4, 0.025), Vector3(0, -0.2, 0), cape_m)
    cape_b = Node3D.new()
    cape_b.position = Vector3(0, -0.4, 0)
    cape_a.add_child(cape_b)
    _part(cape_b, _box(0.44, 0.45, 0.025), Vector3(0, -0.22, 0), cape_m)

    arm_r = Node3D.new()
    arm_r.position = Vector3(0.27, 0.55, 0.0)
    body.add_child(arm_r)
    elbow_r = _build_arm(arm_r, skin_m, armor_m, dark_m)
    arm_l = Node3D.new()
    arm_l.position = Vector3(-0.27, 0.55, 0.0)
    body.add_child(arm_l)
    elbow_l = _build_arm(arm_l, skin_m, armor_m, dark_m)
    leg_r = Node3D.new()
    leg_r.position = Vector3(0.1, -0.07, 0.0)
    body.add_child(leg_r)
    knee_r = _build_leg(leg_r, cloth_m, armor_m, dark_m)
    leg_l = Node3D.new()
    leg_l.position = Vector3(-0.1, -0.07, 0.0)
    body.add_child(leg_l)
    knee_l = _build_leg(leg_l, cloth_m, armor_m, dark_m)

    aura_mat = ShaderMaterial.new()
    aura_mat.shader = AURA
    aura_mat.set_shader_parameter("aura_color", aura)
    aura_mat.set_shader_parameter("intensity", 0.0)
    aura_mesh = _part(self, _capsule(0.95, 3.0), Vector3(0, 0.3, 0), aura_mat)
    aura_mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    aura_mesh.visible = false
    aura_core_mat = ShaderMaterial.new()
    aura_core_mat.shader = AURA
    aura_core_mat.set_shader_parameter("aura_color", Color(1, 1, 1))
    aura_core_mat.set_shader_parameter("intensity", 0.0)
    aura_core_mat.set_shader_parameter("speed", 5.0)
    aura_core = _part(self, _capsule(0.7, 2.5), Vector3(0, 0.3, 0), aura_core_mat)
    aura_core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    aura_core.visible = false

    particles = CPUParticles3D.new()
    particles.amount = 40
    particles.lifetime = 0.8
    particles.emitting = false
    particles.local_coords = false
    particles.direction = Vector3.UP
    particles.spread = 15.0
    particles.initial_velocity_min = 3.0
    particles.initial_velocity_max = 6.0
    particles.gravity = Vector3.ZERO
    particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    particles.emission_sphere_radius = 0.7
    particles.scale_amount_min = 0.6
    particles.scale_amount_max = 1.6
    particles.mesh = main.make_dot_mesh(Color(aura.r * 1.8, aura.g * 1.8, aura.b * 1.8), 0.05)
    pmat = particles.mesh.material
    add_child(particles)
    if player_flag:
        _load_external("res://models/player.glb")
    else:
        _load_external("res://models/enemy.glb")


func set_hair(c, g):
    hair_now = c
    hair_mat.albedo_color = c
    hair_mat.emission_enabled = g > 0.0
    hair_mat.emission = c
    hair_mat.emission_energy_multiplier = g


func reset(pos):
    position = pos
    hp = max_hp
    ki = 100.0
    spark = 0.0
    spark_time = 0.0
    vel = Vector3.ZERO
    stun = 0.0
    atk_cd = 0.0
    blast_cd = 0.0
    dash_t = 0.0
    dash_cd = 0.0
    dash_rush = false
    invuln = 0.0
    charging = false
    ult_t = 0.0
    ult_pending = false
    hit_t = 0.0
    combo = 0
    swing = 0.0
    pose_blast = 0.0
    aura_i = 0.0
    ai_t = 0.5
    ai_mode = "approach"
    anim_cur = ""
    set_hair(hair_col, 0.0)
    model.rotation = Vector3.ZERO
    model.position = Vector3.ZERO
    arm_r.rotation = Vector3(0, 0, 0.17)
    arm_l.rotation = Vector3(0, 0, -0.17)


func snap_face():
    var f = _flat_to_opp()
    model.rotation.y = atan2(-f.x, -f.z)


func _flat_to_opp():
    var d = opp.position - position
    d.y = 0.0
    if d.length() < 0.01:
        return Vector3(0, 0, -1)
    return d.normalized()


func _process(delta):
    anim_t += delta
    if main.state != "fight":
        _idle(delta)
        return
    _timers(delta)
    if hp > 0.0:
        if stun <= 0.0 and ult_t <= 0.0:
            if is_player:
                _player_control(delta)
            else:
                _ai(delta)
        elif ult_t > 0.0:
            vel = vel.lerp(Vector3.ZERO, 1.0 - exp(-10.0 * delta))
        else:
            vel = vel.lerp(Vector3.ZERO, 1.0 - exp(-3.0 * delta))
    _move(delta)
    _visuals(delta)


func _secondary(delta, fs):
    var k = 1.0 - exp(-8.0 * delta)
    var push = clamp(fs / 25.0, -0.3, 1.0)
    cape_a.rotation.x = lerp(cape_a.rotation.x, -(0.12 + push * 0.8) - sin(anim_t * 6.0) * 0.05, k)
    cape_b.rotation.x = lerp(cape_b.rotation.x, -(0.1 + push * 0.7) - sin(anim_t * 7.0 + 1.0) * 0.12, 1.0 - exp(-5.0 * delta))
    cape_a.rotation.z = sin(anim_t * 3.0) * 0.05
    hair_node.rotation.x = lerp(hair_node.rotation.x, push * 0.5 + sin(anim_t * 5.0) * 0.03, k)
    var hs = 1.0
    if spark_time > 0.0:
        hs = 1.18
    hair_node.scale = hair_node.scale.lerp(Vector3(1, hs, 1), k)


func _idle(delta):
    charging = false
    if is_player:
        main.sfx.set_loop("charge", false)
    _update_anim()
    model.position.y = sin(anim_t * 2.5) * 0.05
    aura_i = lerp(aura_i, 0.0, 1.0 - exp(-6.0 * delta))
    aura_mat.set_shader_parameter("intensity", aura_i)
    aura_mesh.visible = aura_i > 0.03
    aura_core.visible = aura_mesh.visible
    particles.emitting = false
    _secondary(delta, 0.0)
    if hp <= 0.0:
        vel.y -= 25.0 * delta
        position += vel * delta
        vel.x = lerp(vel.x, 0.0, 1.0 - exp(-2.0 * delta))
        vel.z = lerp(vel.z, 0.0, 1.0 - exp(-2.0 * delta))
        if position.y < 1.1:
            position.y = 1.1
            vel = Vector3.ZERO
        model.rotation.z = lerp(model.rotation.z, 1.4, 1.0 - exp(-4.0 * delta))
        return
    var f = _flat_to_opp()
    model.rotation.y = lerp_angle(model.rotation.y, atan2(-f.x, -f.z), 1.0 - exp(-8.0 * delta))
    model.rotation.x = lerp(model.rotation.x, 0.0, 1.0 - exp(-8.0 * delta))
    model.rotation.z = lerp(model.rotation.z, 0.0, 1.0 - exp(-8.0 * delta))


func _timers(delta):
    atk_cd = max(0.0, atk_cd - delta)
    blast_cd = max(0.0, blast_cd - delta)
    dash_cd = max(0.0, dash_cd - delta)
    invuln = max(0.0, invuln - delta)
    stun = max(0.0, stun - delta)
    pose_blast = max(0.0, pose_blast - delta)
    swing = max(0.0, swing - delta * 4.5)
    if combo_t > 0.0:
        combo_t -= delta
        if combo_t <= 0.0:
            combo = 0
    if dash_t > 0.0:
        dash_t -= delta
        if dash_t <= 0.0:
            vel = dash_dir * 6.0
    if hit_t > 0.0:
        hit_t -= delta
        if hit_t <= 0.0:
            _resolve_hit()
    if ult_t > 0.0:
        ult_t -= delta
        if ult_t <= 0.0 and ult_pending:
            ult_pending = false
            _fire_ult()
    if spark_time > 0.0:
        spark_time -= delta
        if spark_time <= 0.0:
            set_hair(hair_col, 0.0)
    var regen = 3.0
    if charging:
        regen = 32.0
    if spark_time > 0.0:
        regen += 12.0
    ki = clamp(ki + regen * delta, 0.0, 100.0)
    charging = false


func _player_control(delta):
    var h = main.hud
    var fwd = _flat_to_opp()
    var right = fwd.cross(Vector3.UP)
    var to3 = (opp.position - position).normalized()
    var st = h.stick
    var want = to3 * (-st.y) + right * st.x
    var vert = 0.0
    if h.held_btn("up"):
        vert += 1.0
    if h.held_btn("down"):
        vert -= 1.0
    if h.held_btn("charge") and want.length() < 0.2:
        charging = true
    if h.tapped("atk"):
        do_attack()
    if h.held_btn("blast"):
        shoot_blast(0.0)
    if h.tapped("ult"):
        start_ult()
    if h.tapped("dash"):
        var d = want
        if d.length() < 0.2:
            d = right
            if randf() < 0.5:
                d = -right
        start_dash(d.normalized(), 0.18)
    if h.tapped("spark"):
        activate_spark()
    _apply_move(want, vert, delta)


func _ai(delta):
    ai_t -= delta
    var to = opp.position - position
    var dist = to.length()
    var fwd = _flat_to_opp()
    var right = fwd.cross(Vector3.UP)
    if ai_t <= 0.0:
        ai_t = randf_range(0.5, 1.3)
        ai_strafe = 1.0
        if randf() < 0.5:
            ai_strafe = -1.0
        var r = randf()
        if ki < 25.0 and r < 0.6:
            ai_mode = "charge"
        elif dist > 16.0:
            if r < 0.55:
                ai_mode = "approach"
            else:
                ai_mode = "blast"
        elif dist > 6.0:
            if r < 0.3:
                ai_mode = "blast"
            elif r < 0.55:
                ai_mode = "strafe"
            elif r < 0.8:
                ai_mode = "rush"
            else:
                ai_mode = "approach"
        else:
            if r < 0.55:
                ai_mode = "melee"
            elif r < 0.75:
                ai_mode = "strafe"
            elif r < 0.9:
                ai_mode = "retreat"
            else:
                ai_mode = "blast"
    var want = Vector3.ZERO
    if ai_mode == "approach":
        want = to.normalized()
    elif ai_mode == "strafe":
        want = right * ai_strafe + fwd * 0.2
    elif ai_mode == "retreat":
        want = -fwd + right * ai_strafe * 0.5
    elif ai_mode == "melee":
        if dist > 2.8:
            want = to.normalized()
        else:
            want = right * ai_strafe * 0.4
        if dist < 3.6 and randf() < 3.2 * delta:
            do_attack()
    elif ai_mode == "blast":
        want = right * ai_strafe * 0.6
        if randf() < 3.5 * delta:
            shoot_blast(0.12)
    elif ai_mode == "rush":
        if dist > 4.0:
            do_attack()
        ai_mode = "melee"
    elif ai_mode == "charge":
        charging = true
        if ki >= 90.0:
            ai_t = 0.0
    var vert = clamp((opp.position.y - position.y) * 0.4, -1.0, 1.0)
    if ai_mode == "strafe":
        vert += sin(anim_t * 1.5) * 0.5
    if charging:
        want = Vector3.ZERO
        vert = 0.0
    if ki >= 70.0 and dist > 5.0 and randf() < 0.25 * delta:
        start_ult()
    if spark >= 100.0:
        activate_spark()
    if dash_cd <= 0.0:
        for b in get_tree().get_nodes_in_group("blasts"):
            if b.shooter != self and global_position.distance_to(b.global_position) < 7.0 and randf() < 2.5 * delta:
                start_dash(right * ai_strafe, 0.18)
                break
    _apply_move(want, vert, delta)


func _apply_move(want, vert, delta):
    if dash_t > 0.0:
        return
    var spd = 15.0 * speed_mul
    if spark_time > 0.0:
        spd *= 1.3
    var target = Vector3.ZERO
    if not charging:
        target = want.limit_length(1.0) * spd + Vector3.UP * vert * spd * 0.7
    vel = vel.lerp(target, 1.0 - exp(-8.0 * delta))


func _move(delta):
    if dash_t > 0.0:
        vel = dash_dir * 48.0
        if dash_rush and position.distance_to(opp.position) < 2.5:
            dash_t = 0.0
            dash_rush = false
            vel = dash_dir * 4.0
            atk_cd = 0.0
            do_attack()
    else:
        dash_rush = false
    position += vel * delta
    var flat = Vector2(position.x, position.z)
    if flat.length() > 85.0:
        flat = flat.normalized() * 85.0
        position.x = flat.x
        position.z = flat.y
    if position.y < 1.1:
        position.y = 1.1
        if vel.y < 0.0:
            vel.y = 0.0
    position.y = min(position.y, 50.0)
    var d = opp.position - position
    var dist = d.length()
    if dist < 1.4 and dist > 0.01:
        position -= d.normalized() * (1.4 - dist) * 0.5


func start_dash(dir, t):
    if dash_cd > 0.0 or ki < 10.0 or dir.length() < 0.01:
        return false
    ki -= 10.0
    dash_cd = 0.35
    main.sfx.play("dash", -4.0)
    main.spawn_burst(global_position, Color(1, 1, 1), 3.0, 0.3, 0.8, 1.0, false)
    dash_t = t
    dash_dir = dir.normalized()
    invuln = max(invuln, t + 0.05)
    if is_player:
        main.speed_fx = 0.8
    return true


func do_attack():
    if atk_cd > 0.0 or hit_t > 0.0:
        return
    var to = opp.position - position
    if to.length() > 3.8:
        if start_dash(to, 0.3):
            dash_rush = true
            atk_cd = 0.3
        return
    atk_cd = 0.3
    hit_t = 0.1
    swing = 1.0
    attack_n += 1
    kick = (attack_n % 3 == 0)
    if not kick:
        swing_side = -swing_side
    main.sfx.play("swing", -6.0)
    vel = to.normalized() * 7.0


func _resolve_hit():
    if stun > 0.0 or hp <= 0.0 or opp.hp <= 0.0:
        return
    var to = opp.position - position
    if to.length() > 4.4:
        combo = 0
        return
    combo += 1
    combo_t = 1.1
    var heavy = combo >= 5
    var dmg = 36.0 * dmg_mul
    if spark_time > 0.0:
        dmg *= 1.5
    var knock = 5.0
    if heavy:
        dmg *= 1.8
        knock = 30.0
        combo = 0
    var ok = opp.take_hit(dmg, to.normalized(), knock, heavy)
    if ok:
        ki = min(100.0, ki + 4.0)


func shoot_blast(spread):
    if blast_cd > 0.0 or ki < 6.0:
        return
    ki -= 6.0
    blast_cd = 0.2
    pose_blast = 0.3
    main.sfx.play("blast", -5.0)
    var dir = (opp.position + Vector3(0, 0.2, 0) - position).normalized()
    if spread > 0.0:
        dir = (dir + Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)) * spread).normalized()
    var dmg = 28.0 * dmg_mul
    var col = base_aura
    if spark_time > 0.0:
        dmg *= 1.4
        col = Color(1.0, 0.85, 0.3)
    _spawn_blast(dir, dmg, 0.35, 34.0, 1.2, col, false)


func start_ult():
    if ult_t > 0.0 or ki < 60.0 or stun > 0.0:
        return
    ki -= 60.0
    ult_t = 0.75
    ult_pending = true
    main.sfx.play("ult_charge", -3.0)
    main.shake = max(main.shake, 0.15)


func _fire_ult():
    var dir = (opp.position + Vector3(0, 0.2, 0) - position).normalized()
    var dmg = 190.0 * dmg_mul
    var col = base_aura
    if spark_time > 0.0:
        dmg *= 1.3
        col = Color(1.0, 0.85, 0.3)
    _spawn_blast(dir, dmg, 1.3, 26.0, 0.9, col, true)
    main.sfx.play("ult_fire", -1.0)
    main.flash = max(main.flash, 0.35)
    main.shake = 0.5
    pose_blast = 0.6


func _spawn_blast(dir, dmg, radius, spd, hom, col, big):
    var b = BlastScript.new()
    b.setup(main, self, opp, dmg, col, radius, spd, hom, big)
    main.add_child(b)
    b.global_position = global_position + dir * 1.3 + Vector3(0, 0.2, 0)
    b.vel = dir * spd


func activate_spark():
    if spark < 100.0 or spark_time > 0.0:
        return
    spark = 0.0
    spark_time = 14.0
    main.sfx.play("spark", -2.0)
    hp = min(max_hp, hp + 120.0)
    ki = 100.0
    set_hair(Color(1.0, 0.82, 0.2), 0.8)
    main.shake = 0.6
    main.flash = 0.6
    main.hitstop = max(main.hitstop, 0.1)
    main.spawn_explosion(global_position, Color(1.0, 0.8, 0.2), 3.5)


func take_hit(dmg, dir, knock, heavy = false):
    if invuln > 0.0 or hp <= 0.0:
        return false
    hp = max(0.0, hp - dmg)
    vel = dir * knock
    if heavy:
        stun = 0.5
    else:
        stun = 0.2
    hit_t = 0.0
    ult_pending = false
    ult_t = 0.0
    dash_t = 0.0
    dash_rush = false
    combo = 0
    spark = min(100.0, spark + dmg * 0.07)
    opp.spark = min(100.0, opp.spark + dmg * 0.04)
    main.spawn_hit_fx(global_position + Vector3(0, 0.3, 0), heavy)
    var pc = Color(1, 1, 1)
    if heavy:
        pc = Color(1.0, 0.85, 0.3)
        main.sfx.play("heavy")
        main.flash = max(main.flash, 0.15)
    else:
        main.sfx.play("punch", -3.0)
    main.hud.popup(global_position + Vector3(0, 1.3, 0), str(int(dmg)), pc, heavy)
    if heavy:
        main.shake = max(main.shake, 0.4)
        main.hitstop = max(main.hitstop, 0.08)
    else:
        main.shake = max(main.shake, 0.12)
        main.hitstop = max(main.hitstop, 0.03)
    if hp <= 0.0:
        main.on_ko(self)
    return true


func _visuals(delta):
    var f = _flat_to_opp()
    model.rotation.y = lerp_angle(model.rotation.y, atan2(-f.x, -f.z), 1.0 - exp(-14.0 * delta))
    var side_dir = f.cross(Vector3.UP)
    var fs = vel.dot(f)
    var lean = clamp(fs / 30.0, -0.3, 1.0) * 0.9
    var roll = clamp(vel.dot(side_dir) / 20.0, -1.0, 1.0) * 0.35
    var k = 1.0 - exp(-10.0 * delta)
    model.rotation.x = lerp(model.rotation.x, -lean, k)
    model.rotation.z = lerp(model.rotation.z, -roll, k)
    model.position.y = sin(anim_t * 2.5) * 0.05

    var blast_a = 0.0
    if pose_blast > 0.0:
        blast_a = 1.45
    var out = 0.17
    if charging or ult_t > 0.0:
        out = 0.77
    var pr = 0.0
    var pl = 0.0
    var kk = 0.0
    if kick:
        kk = swing * 1.6
    elif swing_side > 0:
        pr = swing * 1.7
    else:
        pl = swing * 1.7
    var ka = 1.0 - exp(-22.0 * delta)
    sm_pr = lerp(sm_pr, pr + blast_a, ka)
    sm_pl = lerp(sm_pl, pl + blast_a, ka)
    sm_out = lerp(sm_out, out, 1.0 - exp(-10.0 * delta))
    var er = 0.5
    var el = 0.5
    if blast_a > 0.0:
        er = 0.1
        el = 0.1
    elif pr > 0.3:
        er = 0.05
    elif pl > 0.3:
        el = 0.05
    sm_er = lerp(sm_er, er, ka)
    sm_el = lerp(sm_el, el, ka)
    arm_r.rotation.x = sm_pr
    arm_l.rotation.x = sm_pl
    arm_r.rotation.z = sm_out
    arm_l.rotation.z = -sm_out
    elbow_r.rotation.x = sm_er
    elbow_l.rotation.x = sm_el
    var sway = sin(anim_t * 3.0) * 0.12
    var trail = clamp(vel.length() / 20.0, 0.0, 1.0) * 0.5
    leg_r.rotation.x = sway - trail + kk
    leg_l.rotation.x = -sway - trail
    var kb = 0.15 + trail * 0.6
    knee_r.rotation.x = -kb
    knee_l.rotation.x = -(kb + 0.12 * sin(anim_t * 3.0 + 1.0))
    if kick and swing > 0.2:
        knee_r.rotation.x = -0.05
    _secondary(delta, fs)

    var target_i = 0.0
    if charging:
        target_i = 1.0
    if ult_t > 0.0:
        target_i = 1.5
    if spark_time > 0.0:
        target_i = max(target_i, 0.8)
    if dash_t > 0.0:
        target_i = max(target_i, 0.7)
    aura_i = lerp(aura_i, target_i, 1.0 - exp(-10.0 * delta))
    var ac = base_aura
    if spark_time > 0.0:
        ac = Color(1.0, 0.82, 0.25)
    aura_mat.set_shader_parameter("aura_color", ac)
    aura_mat.set_shader_parameter("intensity", aura_i)
    aura_core_mat.set_shader_parameter("aura_color", ac.lerp(Color(1, 1, 1), 0.6))
    aura_core_mat.set_shader_parameter("intensity", aura_i * 0.6)
    aura_mesh.visible = aura_i > 0.03
    aura_core.visible = aura_mesh.visible
    var pulse = (1.0 + 0.04 * sin(anim_t * 20.0)) * (1.0 + 0.3 * clamp(aura_i - 1.0, 0.0, 1.0))
    aura_mesh.scale = Vector3.ONE * pulse
    aura_core.scale = Vector3.ONE * pulse
    particles.emitting = aura_i > 0.4
    pmat.albedo_color = Color(ac.r * 1.8, ac.g * 1.8, ac.b * 1.8)
    if is_player:
        main.sfx.set_loop("charge", charging, -9.0)
    if charging:
        charge_fx_t -= delta
        if charge_fx_t <= 0.0:
            charge_fx_t = 0.35
            main.spawn_burst(global_position + Vector3(0, 0.2, 0), ac, 4.5, 0.55, 1.0, 0.0, false)
    if position.y < 4.0 and vel.length() > 8.0:
        dust_t -= delta
        if dust_t <= 0.0:
            dust_t = 0.1
            main.dust_puff(Vector3(position.x, 0.2, position.z), 1.0)
    _update_anim()


func _meshes(n):
    var out = []
    if n is MeshInstance3D:
        out.append(n)
    for c in n.get_children():
        out.append_array(_meshes(c))
    return out


func _find_anim(n):
    if n is AnimationPlayer:
        return n
    for c in n.get_children():
        var r = _find_anim(c)
        if r != null:
            return r
    return null


func _find_clip(keys):
    var names = []
    for a in anim.get_animation_list():
        if str(a) != "RESET":
            names.append(str(a))
    for k in keys:
        for a in names:
            if a.to_lower().begins_with(k):
                return a
    for k in keys:
        for a in names:
            if a.to_lower().contains(k):
                return a
    return ""


func _load_external(path):
    if not ResourceLoader.exists(path):
        return
    var res = load(path)
    if res == null or not (res is PackedScene):
        return
    for c in model.get_children():
        c.visible = false
    ext = Node3D.new()
    model.add_child(ext)
    var inst = res.instantiate()
    ext.add_child(inst)
    inst.rotation.y = PI
    var lo = INF
    var hi = -INF
    for mi in _meshes(inst):
        if mi.mesh == null:
            continue
        var bb = mi.get_aabb()
        for i in 8:
            var corner = bb.position + bb.size * Vector3(i & 1, (i >> 1) & 1, (i >> 2) & 1)
            var wp = mi.global_transform * corner
            lo = min(lo, wp.y)
            hi = max(hi, wp.y)
        for s in mi.mesh.get_surface_count():
            var m = mi.get_active_material(s)
            if m is BaseMaterial3D and not is_player:
                var d = m.duplicate()
                d.albedo_color = Color(0.8, 0.6, 1.0)
                mi.set_surface_override_material(s, d)
    if hi - lo > 0.01:
        var sc = 1.9 / (hi - lo)
        ext.scale = Vector3.ONE * sc
        ext.position.y = -1.0 - (lo - global_position.y) * sc
    anim = _find_anim(inst)
    if anim != null:
        for st in CLIP_KEYS.keys():
            var c = _find_clip(CLIP_KEYS[st])
            clips[st] = c
            if c != "" and (st == "idle" or st == "move" or st == "charge"):
                anim.get_animation(c).loop_mode = Animation.LOOP_LINEAR


func _update_anim():
    if anim == null:
        return
    var s = "idle"
    if hp <= 0.0:
        s = "ko"
    elif stun > 0.0:
        s = "hurt"
    elif charging or ult_t > 0.0:
        s = "charge"
    elif swing > 0.25:
        s = "punch"
    elif pose_blast > 0.0:
        s = "blast"
    elif dash_t > 0.0:
        s = "dash"
    elif vel.length() > 3.0:
        s = "move"
    var clip = clips.get(s, "")
    if clip == "":
        clip = clips.get("idle", "")
    if clip == "":
        return
    if s != anim_cur or (s == "punch" and swing_side != last_side):
        anim_cur = s
        last_side = swing_side
        anim.play(clip, 0.12)
