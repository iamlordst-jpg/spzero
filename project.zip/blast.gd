extends Node3D

var main
var shooter
var target
var vel = Vector3.FORWARD
var speed = 30.0
var dmg = 30.0
var radius = 0.4
var homing = 1.0
var big = false
var col = Color.WHITE
var life = 5.0


func setup(m, s, t, d, c, r, spd, hom, is_big):
    main = m
    shooter = s
    target = t
    dmg = d
    col = c
    radius = r
    speed = spd
    homing = hom
    big = is_big


func _ready():
    add_to_group("blasts")
    var core = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sm.radius = radius * 0.65
    sm.height = radius * 1.3
    sm.radial_segments = 16
    sm.rings = 8
    var cm = StandardMaterial3D.new()
    cm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cm.albedo_color = Color(3.0, 3.0, 3.0)
    core.mesh = sm
    core.material_override = cm
    core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(core)
    var outer = MeshInstance3D.new()
    var so = SphereMesh.new()
    so.radius = radius * 1.15
    so.height = radius * 2.3
    so.radial_segments = 16
    so.rings = 8
    var om = StandardMaterial3D.new()
    om.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    om.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    om.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    om.albedo_color = Color(col.r * 2.0, col.g * 2.0, col.b * 2.0, 0.7)
    outer.mesh = so
    outer.material_override = om
    outer.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(outer)
    var p = CPUParticles3D.new()
    p.amount = 24
    p.lifetime = 0.5
    p.local_coords = false
    p.direction = Vector3.UP
    p.spread = 180.0
    p.initial_velocity_min = 0.5
    p.initial_velocity_max = 1.5
    p.gravity = Vector3.ZERO
    p.scale_amount_min = radius * 2.0
    p.scale_amount_max = radius * 3.5
    p.mesh = main.make_dot_mesh(Color(col.r * 2.5, col.g * 2.5, col.b * 2.5), 0.07)
    add_child(p)
    p.emitting = true


func _process(delta):
    if main.state == "title":
        queue_free()
        return
    life -= delta
    if life <= 0.0:
        queue_free()
        return
    if homing > 0.0 and is_instance_valid(target) and target.hp > 0.0:
        var want = (target.global_position + Vector3(0, 0.2, 0) - global_position).normalized()
        var cur = vel.normalized()
        var ang = cur.angle_to(want)
        if ang > 0.001 and ang < 3.0:
            var t = min(1.0, homing * delta / ang)
            cur = cur.slerp(want, t)
            vel = cur * speed
    global_position += vel * delta
    if is_instance_valid(target) and target.hp > 0.0:
        if (target.global_position - global_position).length() < radius + 0.75:
            var knock = 10.0
            if big:
                knock = 28.0
            var hit = target.take_hit(dmg, vel.normalized(), knock, big)
            if hit:
                main.spawn_explosion(global_position, col, radius * 4.0)
                queue_free()
                return
    if global_position.y < 0.25:
        main.spawn_explosion(global_position, col, radius * 3.5)
        if big:
            main.shake = max(main.shake, 0.3)
        queue_free()
